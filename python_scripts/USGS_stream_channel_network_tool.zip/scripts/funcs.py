# -*- coding: utf-8 -*-
#-------------------------------------------------------------------------------
# editor: by Adrian Wiemgan 2020-09-22 
# revisions:
# 	- converted from python 2.4.x to 3.x using python-modernize -w scriptname.py
#   - replaced all tabs with 4 spaces
# notes: 
# 	- these changes allow the tool to be compatible with ArcGIS Pro 2.x and python 3.x
"""
Created on Thu Dec 18 05:54:55 2014

@author: sjlamont
"""
from __future__ import absolute_import
from __future__ import print_function
import arcpy
##arcpy.CheckOutExtension("Spatial")
##from arcpy.sa import * # Spatial Analyst
##from arcpy import env
##arcpy.overwriteOutputs = True

import shapefile
import numpy as np
from scipy import ndimage, arange, interpolate
from math import isinf, sqrt, hypot, modf, atan, ceil
import matplotlib.pyplot as plt
import os.path
from six.moves import range

##import collections
##from itertools import chain, izip

##-----------------------------------------------------------------------------
    # Check num of rows and cols for input grids...
##-----------------------------------------------------------------------------
def input_grid_error(str_path1, str_path2, str_path3, str_path4):

    # NOTE: height --> rows; width --> cols
    try:

        boolError = True

        rast1 = arcpy.Raster(str_path1)
        rast2 = arcpy.Raster(str_path2)
        rast3 = arcpy.Raster(str_path3)
        rast4 = arcpy.Raster(str_path4)

        if rast1.height == rast2.height and rast2.height == rast3.height and rast3.height == rast4.height and rast1.width == rast2.width and rast2.width == rast3.width and rast3.width == rast4.width:
            boolError = False

    except arcpy.ExecuteError:
        arcpy.AddMessage(arcpy.GetMessages(2))

    return boolError
##-----------------------------------------------------------------------------
    # Get properties of DEM grid...
##-----------------------------------------------------------------------------
def get_dem_props(str_path):
    # Just use Describe here for all?

    try:
        DEMrast = arcpy.Raster(str_path)

        arcpy.CalculateStatistics_management(DEMrast)

        dEM_RowCount = DEMrast.height
        dEM_CellSizeX = DEMrast.meanCellWidth

        dEM_Extent = DEMrast.extent
        dEM_ExtentLeft = dEM_Extent.XMin
        dEM_ExtentBottom = dEM_Extent.YMin

        dEM_minVal = DEMrast.minimum
        dEM_maxVal = DEMrast.maximum

        dEMdesc = arcpy.Describe(str_path)
        dEMspatRef = dEMdesc.spatialReference
        dEMspatRefName = dEMspatRef.exportToString()

        if dEM_minVal < 0:
            dEM_minVal = 0

        lst_output = [dEM_RowCount, dEM_CellSizeX, dEM_ExtentLeft, dEM_ExtentBottom, dEM_minVal, dEM_maxVal, dEMspatRefName]

    except arcpy.ExecuteError:
        arcpy.AddMessage(arcpy.GetMessages(2))

    return lst_output
##-----------------------------------------------------------------------------
    # Process the SRC grid creating a list of unique reach LINKNOs (unique values)...
##-----------------------------------------------------------------------------
def get_linknos(stpt_filename):

##    env.workspace = str_workspace

    try:
        # Bring the reach grid into NumPy...
        #print 'Reading SRC grid...'
        stpt_array= arcpy.RasterToNumPyArray(stpt_filename,nodata_to_value=-9999)



    ##    ## TESTING...
    ##    lst_Indx = []
    ##    test_1D = stpt_array.ravel()
    ##    test = test_1D.index(4)
    ####    for i in range(len(test_1D)):
    ####        if test_1D[i] > 0:
    ####            lst_Indx.append(test_1D[i])


        lstLinkNums = []

        lstLinkNums = np.unique(stpt_array) # this returns an array, sorted

    except arcpy.ExecuteError:
        arcpy.AddMessage(arcpy.GetMessages(2))

    # src_array is automatically dumped here?
    return lstLinkNums
##-----------------------------------------------------------------------------
    # Process the StartPts grid creating a list of reach channel head row/col coordinates...
##-----------------------------------------------------------------------------
def get_startpts(lst_linknos, spts_filename, linkno_test, nodata_val):
    """
        Gets the row/col index of the reaches in lst_linknos

        NOTE: Set LINKNO here for testing
    """
    lst_startpts = []

##    env.workspace = str_workspace

    try:

        # Bring the reach grid into NumPy...
        #print 'Reading Start Pts grid...'
        startpts_array= arcpy.RasterToNumPyArray(spts_filename,nodata_to_value=nodata_val) # can you just skip NoData vals here?

        # change to int for speed??
        #int_startpts_array = np.int16(startpts_array)
        startpts_array = startpts_array.astype(int)

        ## Test version ------------------------------>
    ##    test_ravel = int_startpts_array.ravel()
    ##    test_mesh = np.meshgrid(test_ravel,lst_linknos)

    ##    test_arr = ([2,4,3,9,8])
    ##    test_unique = ([3,4,8])
    ##    uind = np.digitize(test_arr, test_unique) - 1
    ##    vals = uind.argsort()
    ##
    ##    #test_var = startpts_array.ravel()
    ##    uind = np.digitize(startpts_array.ravel(), lst_linknos) - 1
    ##    vals = uind.argsort()
    ##    count = np.bincount(uind)
    ##


    ##    result = collections.defaultdict(list) # defines result as a collection
    ##    #for val, idx in IT.izip(int_startpts_array.ravel(), int_startpts_array.ravel()):
    ##    for idx, val in int_startpts_array.flat:
    ##        result[idx].append(val)
    ##
    ##    for idx in lst_linknos:
    ##        test = result[idx]

        tpl_shp = np.shape(startpts_array)
        tot_cols = tpl_shp[1]

    ##    total_len = tpl_shp[0]*tpl_shp[1]
    ##
    ##    indx_arr = np.arange(0,total_len)
        # Create an index column with ravel, zip together, then sort, then use
        # searchsorted to find ind (get actual index from sorted ind)
        # NOTE: make sure array and element are of same data type to increase speed??
    ##    arr = np.array(startpts_array.ravel(),indx_arr)
    ##    arr.sort()

    ##    sorted_arr = np.array(sorted(izipped, key = lambda t: t[1]))
        sorted_arr = np.sort(startpts_array.ravel())
        sorted_inds = np.argsort(startpts_array.ravel())


        # FOR TEST FUNCTION...
        startpts_array_rav = startpts_array.ravel()



        # For processing of one LINKNO only...
        if len(linkno_test) == 1 and linkno_test[0] != 0:
            lst_linknos = linkno_test
        elif len(linkno_test) > 1:
            lst_linknos = linkno_test
    ##    elif linkno_test > 0:
    ##        lst_linknos = [linkno_test]

        for this_linkno in lst_linknos:

            ## Numpy.nonzero version --------------------->
            if 0 < this_linkno < 10000: # get the NoData value??

    ##            bool_array = (int_startpts_array == this_linkno)
    ##            this_startpt = np.nonzero(bool_array)
    ##            this_startpt = this_startpt + (this_linkno,)
    ##            lst_startpts.append(this_startpt)

    ##            ## TEST FUNCTION...
    ##            result = find(startpts_array_rav, lambda arr: arr == this_linkno) # USE INT ARRAY HERE??
    ##            tpl_out = next(result)
    ##            flat_indx = tpl_out[0][0]

                ## Search sorted...
                sorted_ind = np.searchsorted(sorted_arr, this_linkno) # put ravel statements in here instead of making a copy??
                flat_indx = sorted_inds[sorted_ind]

                # Convert flat index to row/col...
                dec, row = modf(flat_indx/tot_cols)
                col = flat_indx - (row*tot_cols)

                this_startpt = (int(row),int(col),this_linkno)
                lst_startpts.append(this_startpt)

            ## NumPy.where version --------------------->
    ##            # Get the row/column of this reach start point...REVISIT THIS
    ##            this_startpt = np.where( int_startpts_array == this_linkno ) # this shit is slow!!
    ##            # thisStartPt = np.nonzero(StartPtarray == thisLINKNO) # not sure if this is any faster
    ##
    ##            # NOTE: this returns X-Y not row-col??
    ##
    ##            this_startpt = this_startpt + (this_linkno,)
    ##            lst_startpts.append(this_startpt)

            ## Flatten version??----------------------->
    ##            stpts_flat = startpts_array.flatten()
    ##            this_startpt = np.where( stpts_flat == this_linkno )


            ##test = startpts_array[startpts_array == this_linkno]

            ## Array search version ------------------->
    ##        tpl_shape = startpts_array.shape
    ##
    ##        for i_col in range(0, tpl_shape[1]):
    ##            if this_linkno in startpts_array[:,i_col]:
    ##                this_col = i_col
    ##                break
    ##
    ##        for i_row in range(0, tpl_shape[0]):
    ##            if this_linkno in startpts_array[i_row,:]:
    ##                this_row = i_row
    ##                break
    ##
    ##        lst_startpts.append((i_row, i_col, this_linkno))

    except arcpy.ExecuteError:
        arcpy.AddMessage(arcpy.GetMessages(2))

    return lst_startpts
##-----------------------------------------------------------------------------
    # Process the FDR grid creating a list of reach coordinates...
##-----------------------------------------------------------------------------
def get_reachcoords(lst_startpts, fdr_filename, w_filename):

    try:
        # Output:
        lst_reachcoords = [] # list of tuples of lists
        tpl_coords = ([],[]) # row/col lists for each reach

    ##    env.workspace = str_workspace

        # Bring the reach grid into NumPy...
        #print 'Reading FDR grid...'
        fdr_array= arcpy.RasterToNumPyArray(fdr_filename)

##        if np.any(fdr_array == 128): # spatial analyst version
##            right = 1
##            up_right = 128
##            above = 64
##            up_left = 32
##            left = 16
##            low_left = 8
##            below = 4
##            low_right = 2
##        else: # TauDEM
##            right = 1
##            up_right = 2
##            above = 3
##            up_left = 4
##            left = 5
##            low_left = 6
##            below = 7
##            low_right = 8

        right = 1
        up_right = 2
        above = 3
        up_left = 4
        left = 5
        low_left = 6
        below = 7
        low_right = 8

        #print 'Reading Catchments grid...'
        w_array= arcpy.RasterToNumPyArray(w_filename)

        ## Reach Loop--------------------------------------------------------->
        for tpl_thisstartpt in lst_startpts:

            # Initialize lists...
            listReachRows = []
            listReachCols = []

    #            thisStartPt_row = tplThisStartPt[0][0]
    #            thisStartPt_col = tplThisStartPt[1][0]
            thisStartPt_linkno = tpl_thisstartpt[2]

    ##        print 'Link Num: {}'.format(thisStartPt_linkno)

    #                thisRow = thisStartPt[0][0]
    #                thisCol = thisStartPt[1][0]

            ## TEST using search function instead of where...
            # Load the first start point for this reach...
            listReachRows.append(tpl_thisstartpt[0])
            listReachCols.append(tpl_thisstartpt[1])

    ##        # Load the first start point for this reach...
    ##        listReachRows.append(tpl_thisstartpt[0][0])
    ##        listReachCols.append(tpl_thisstartpt[1][0])

            # Make sure the start point and the catchment are coincident...
            # Use a polygon here instead??
            i = w_array[listReachRows[0],listReachCols[0]]

            j=0
            while i == thisStartPt_linkno:

    #                testlstRows = listReachRows[-1]
    #                testlstCols = listReachCols[-1]
    #                testFDRindeRows = fdr_array[listReachRows[-1],listReachCols[-1]]

                if (fdr_array[listReachRows[j],listReachCols[j]]==right): # to the right
                    listReachRows.append(listReachRows[j])
                    listReachCols.append(listReachCols[j]+1)

                elif (fdr_array[listReachRows[j],listReachCols[j]]==up_right): # upper right
                    listReachRows.append(listReachRows[j]-1)
                    listReachCols.append(listReachCols[j]+1)

                elif (fdr_array[listReachRows[j],listReachCols[j]]==above): # above
                    listReachRows.append(listReachRows[j]-1)
                    listReachCols.append(listReachCols[j])

                elif (fdr_array[listReachRows[j],listReachCols[j]]==up_left): # upper left
                    listReachRows.append(listReachRows[j]-1)
                    listReachCols.append(listReachCols[j]-1)

                elif (fdr_array[listReachRows[j],listReachCols[j]]==left): # left
                    listReachRows.append(listReachRows[j])
                    listReachCols.append(listReachCols[j]-1)

                elif (fdr_array[listReachRows[j],listReachCols[j]]==low_left): # lower left
                    listReachRows.append(listReachRows[j]+1)
                    listReachCols.append(listReachCols[j]-1)

                elif (fdr_array[listReachRows[j],listReachCols[j]]==below): # below
                    listReachRows.append(listReachRows[j]+1)
                    listReachCols.append(listReachCols[j])

                elif (fdr_array[listReachRows[j],listReachCols[j]]==low_right): # lower right
                    listReachRows.append(listReachRows[j]+1)
                    listReachCols.append(listReachCols[j]+1)
                else:
                    print('Something is wrong with the FDR direction selection')

               # Some controls on the while loop...IS THIS NECESSARY?
                if (j <= 3): # Sometimes there is weirdness in piRowsel starting points
                    i = thisStartPt_linkno
                elif (listReachRows[-1] <= w_array.shape[0]) and (listReachCols[-1] <= w_array.shape[1]) and (listReachRows[-1] > 0) and (listReachCols[-1] > 0): # Make sure you're staying within the bounds of the grid
                    i = w_array[listReachRows[-1],listReachCols[-1]]
                else:
                    break # skip this iteration

                j = j + 1

                # Is this really necessary?
                if (j>5000):
                    print('Stuck in an infinite loop!')
                    break # get out of while loop

            tpl_coords = (listReachRows, listReachCols)
            tpl_coords = tpl_coords + (thisStartPt_linkno,) # add the link num for reference

            lst_reachcoords.append(tpl_coords)

    except arcpy.ExecuteError:
        arcpy.AddMessage(arcpy.GetMessages(2))

    return lst_reachcoords

##-----------------------------------------------------------------------------
    # Build the Xns for this reach...
##-----------------------------------------------------------------------------
def buildxns_fromcoords_geonet(lst_reachrows, lst_reachcols, parm_xngap, parm_xnfit, parmxn_length, cellsize):
    """
          ORIGINAL GEONET CODE

          # 1. Loop along the fit length of the reach and create resultantSum (where centerline are the RowCol pairs for the current reach)
                (note: subtract out the minimum values here??)
          # 2. Compute the hypotenuse/magnitude
          # 3. Do the rest!

            NOTE: This is about 3x faster than the slope-intercept version!

          for r = -Parameters.resultantVector:Parameters.resultantVector
               resultantSum(1) = resultantSum(1) + centerline(1,i-r); # the sum of all the rows
               resultantSum(2) = resultantSum(2) + centerline(2,i-r); # the sum of all the cols

           resultantMagnitude = sqrt(resultantSum(1)^2 + resultantSum(2)^2);

           resultantSum = resultantSum/resultantMagnitude ;
           orthoResultant = [-resultantSum(2) resultantSum(1)];

           orthoResultant = orthoResultant ./norm(orthoResultant);

           crossSectionX = [-Parameters.crosssectionLength:Parameters.crosssectionLength] * orthoResultant(1) + pixelAtCrosssection(1);
           crossSectionY = [-Parameters.crosssectionLength:Parameters.crosssectionLength] * orthoResultant(2) + pixelAtCrosssection(2);

    """
    # Define some parameters...(all in units of # of cells)
##    paramXnGap = 3      # spacing between Xn's
##    paramFitLength = 5  # this is actually half of the actual fit length
##    paramXnlength = 30  # half of the Xn length

    paramXnGap = int(parm_xngap/cellsize)
    paramFitLength = int(parm_xnfit/(2*cellsize))
    paramXnlength = int(parmxn_length/(2*cellsize))

    paramXnSteps = paramXnlength *2 + 10      # controls the number of points along each Xn (step along -paramXnlength:paramXnlength).  Addition value is arbitrary!

    lst_xnrowcols = []

    try:

        # Loop along the reach at the specified intervals...(Xn loop)
        for i in range( paramFitLength+1, len(lst_reachrows) - paramFitLength, paramXnGap ):

            ## TESTING
##            lstThisSegmentRows = []
##            lstThisSegmentCols = []
##            lstEvalRows = []
##
##            # Get a segment as defined by the fit length...
##            for r in range( -paramFitLength, paramFitLength, 1 ):
##                lstThisSegmentRows.append(lst_reachrows[i-r])
##                lstThisSegmentCols.append(lst_reachcols[i-r])
##
####            # Create a linear fit...
####            # Might need to check if it's near vertical first??
####            if (max(lstThisSegmentCols) - min(lstThisSegmentCols) < 3):
####                m_init = 9999.0
####            else:
####                LinFit = np.polyfit(lstThisSegmentCols,lstThisSegmentRows,1)
####                m_init = LinFit[0]
####                # Evaluate the fit...
####                for r in lstThisSegmentCols:
####                    lstEvalRows.append(m_init*r + LinFit[1])
##
##            # Create a linear fit...
####            LinFit = np.polyfit(lstThisSegmentCols,lstThisSegmentRows,1)
##            # Might need to check if it's near vertical first??
##            if (max(lstThisSegmentCols) - min(lstThisSegmentCols) < 3):
##                m_init = 9999.0
##                y_int = 0
##            else:
##                LinFit = np.polyfit(lstThisSegmentCols,lstThisSegmentRows,1)
##                m_init = LinFit[0]
##                y_int = LinFit[1]
##
##            # Evaluate the fit...
##            for r in lstThisSegmentCols:
##                lstEvalRows.append(m_init*r + y_int)
##
##            min_rows = min(lstEvalRows)
##            max_rows = max(lstEvalRows)

            ## END TESTING

            #XnCntr = XnCntr + 1
            resultantsumRow = 0
            resultantsumCol = 0

            # Get a segment as defined by the fit length and create resultantsum...
            min_rows = min(lst_reachrows[i-paramFitLength:i+paramFitLength])
            min_cols = min(lst_reachcols[i-paramFitLength:i+paramFitLength])

            max_rows = max(lst_reachrows[i-paramFitLength:i+paramFitLength])
            max_cols = max(lst_reachcols[i-paramFitLength:i+paramFitLength])

            resultantsumRow = max_rows - min_rows
            resultantsumCol = max_cols - min_cols


##            for r in range( -paramFitLength, paramFitLength, 1 ):
##                resultantsumRow = resultantsumRow + lst_reachrows[i-r] - min_rows
##                resultantsumCol = resultantsumCol + lst_reachcols[i-r] - min_cols

            # XY SPACE
            resultantMagnitude = hypot(resultantsumRow,resultantsumCol) # what about when one of these is zero?

            resultantsumRow = resultantsumRow/resultantMagnitude
            resultantsumCol = resultantsumCol/resultantMagnitude

            orthoRow = resultantsumCol # XY space?
            orthoCol = resultantsumRow

            # why is this necessary??
##            vec = np.array([orthoCol,orthoRow])
##            orthoRow = orthoRow/np.linalg.norm(vec)
##            orthoCol = orthoCol/np.linalg.norm(vec)

            fit_row_ortho = []
            fit_col_ortho = []
            for r in range(-paramXnlength,paramXnlength,1):
                fit_row_ortho.append(r*orthoRow + lst_reachrows[i])
                fit_col_ortho.append(r*orthoCol + lst_reachcols[i])

            # Save to tuple of lists...
            tplThisXnRowCols = ([],[])
            tplThisXnRowCols = (fit_row_ortho, fit_col_ortho)

            lst_xnrowcols.append(tplThisXnRowCols) # a list of tuples of lists (is this necessary here?)

    except Exception as e:
        print(e.message + ':  build Xn''s GeoNet style')

    return lst_xnrowcols
##-----------------------------------------------------------------------------
    # Build the Xns for this reach...
##-----------------------------------------------------------------------------
def buildxns_fromcoords(lst_reachrows, lst_reachcols, parm_xngap, parm_xnfit, parmxn_length, cellsize, parm_xnptdist, bool_isvalley):
    """
        Builds Xns from row-column pairs representing pixels along a reach segment

        Input: a list of tuples (row, col, linkno) for a reach
        Output: list of tuples of lists describing the Xn's along a reach (row, col)

        NOTE: add code to check minimum length of reaches...

        NOTE: row ==> Y; col ==> X

                 # Make sure this reach satisfies the minimum length threshold...
    #            minReachPixels = round(paramMinReachLength/ActualCellSizeX)

    #            if (len(listReachRows) <  round(paramMinReachLength/ActualCellSizeX)):
    #                print 'This reach is too short!'
    #                # Add zeros to summary output text file
    #                # clear some variables?
    #                # continure
    #                continue

    """
#    # For infinity check (slope)...
#    from math import isinf, sqrt
    # For getting elevation along transects...
    #from scipy import ndimage

    # Define some parameters...(all in units of # of cells)
##    paramXnGap = 3      # spacing between Xn's
##    paramFitLength = 5  # this is actually half of the actual fit length
##    paramXnlength = 30  # half of the Xn length

    paramXnGap = int(parm_xngap/cellsize)
    paramFitLength = int(parm_xnfit/(2*cellsize))
    paramXnlength = int(parmxn_length/(2*cellsize))

    # Get distance between points along Xn as a parameter...
    paramXnSteps = parmxn_length/parm_xnptdist

    #paramXnSteps = paramXnlength *2 + 15      # controls the number of points along each Xn (step along -paramXnlength:paramXnlength).  Addition value is arbitrary!

    slopeCutoffVertical = 20 # just a threshold determining when to call a Xn vertical (if it's above this, make it vertical. Otherwise things get whacky?)

    # Initiate a counter and get total length reach...
    #XnCntr = 1;
    #ReachLength = len(lstReachRows)

    lst_xnrowcols = [] # the final output, a list of tuples of XY coordinate pairs for all Xn's for this reach

    # Initialize return lists for testing??
    #lstXn_X = 0
    #lstXn_Y = 0

    XnCntr = 0
    m_init = 0

    reach_len = len(lst_reachrows)

    if reach_len <= paramXnGap:
        arcpy.AddMessage('Less than!')

    # Loop along the reach at the specified intervals...(Xn loop)
##    for i in range( paramFitLength+1, reach_len - paramFitLength, paramXnGap ):
    for i in range( paramXnGap, reach_len-paramXnGap, paramXnGap ):

        lstThisSegmentRows = []
        lstThisSegmentCols = []

##        # Get a segment as defined by the fit length...
##        for r in range( -paramFitLength, paramFitLength, 1 ):
##            lstThisSegmentRows.append(lst_reachrows[i-r])
##            lstThisSegmentCols.append(lst_reachcols[i-r])
##
##        # Get mid-points...
##        midPtRow = lstThisSegmentRows[int(len(lstThisSegmentCols)/2)]
##        midPtCol = lstThisSegmentCols[int(len(lstThisSegmentCols)/2)]

        if paramFitLength > i or i + paramFitLength >= reach_len: # if i + paramFitLength > reach_len
            fitLength = paramXnGap
        else:
            fitLength = paramFitLength

        lstThisSegmentRows.append(lst_reachrows[i+fitLength])
        lstThisSegmentRows.append(lst_reachrows[i-fitLength])
        lstThisSegmentCols.append(lst_reachcols[i+fitLength])
        lstThisSegmentCols.append(lst_reachcols[i-fitLength])


##        # OR, just get start and stop points, make that a line and go perpendicular to that??
##        if paramFitLength > i:
##            lstThisSegmentRows.append(lst_reachrows[i+paramXnGap])
##            lstThisSegmentRows.append(lst_reachrows[i-paramXnGap])
##            lstThisSegmentCols.append(lst_reachcols[i+paramXnGap])
##            lstThisSegmentCols.append(lst_reachcols[i-paramXnGap])
##        elif paramFitLength + i == reach_len:
##            lstThisSegmentRows.append(lst_reachrows[-1])
##            lstThisSegmentRows.append(lst_reachrows[i-paramFitLength])
##            lstThisSegmentCols.append(lst_reachcols[-1])
##            lstThisSegmentCols.append(lst_reachcols[i-paramFitLength])
##        else:
##            lstThisSegmentRows.append(lst_reachrows[i+paramFitLength])
##            lstThisSegmentRows.append(lst_reachrows[i-paramFitLength])
##            lstThisSegmentCols.append(lst_reachcols[i+paramFitLength])
##            lstThisSegmentCols.append(lst_reachcols[i-paramFitLength])



##        midPtRow = lstThisSegmentRows[int(len(lstThisSegmentRows)/2)]
##        midPtCol = lstThisSegmentCols[int(len(lstThisSegmentRows)/2)]

        # midPt index =  i
        #arcpy.AddMessage(i)
        midPtRow = lst_reachrows[i]
        midPtCol = lst_reachcols[i]

##        midPtRow = lstThisSegmentRows[0] - (lstThisSegmentRows[0]-lstThisSegmentRows[-1])/2
##        midPtCol = lstThisSegmentCols[0] - (lstThisSegmentCols[0]-lstThisSegmentCols[-1])/2

        # Also get and save the
        ## END TESTING

##        if (XnCntr == 1):
##            print 'schnell!'
##            # Minimize range in variables...
##            for i, val in enumerate(lstThisSegmentCols):
##                meanval = np.mean(lstThisSegmentCols)
##                if val < meanval:
##                    lstThisSegmentCols[i] = lstThisSegmentCols[i] + meanval/4
##                else:
##                    lstThisSegmentCols[i] = lstThisSegmentCols[i] - meanval/4

        # Create a linear fit...
        # Might need to check if it's near vertical or horizontal first??
##        test_col = max(lstThisSegmentCols) - min(lstThisSegmentCols)
##        test_row = max(lstThisSegmentRows) - min(lstThisSegmentRows)

        if (max(lstThisSegmentCols) - min(lstThisSegmentCols) < 3):
            m_init = 9999.0
        elif (max(lstThisSegmentRows) - min(lstThisSegmentRows) < 3):
            m_init = 0.0001
        else:
            LinFit = np.polyfit(lstThisSegmentCols,lstThisSegmentRows,1) # NOTE: could just use basic math here instead?!
            m_init = LinFit[0]

##        #TestInf = isinf(m_init)
##        ## TESTING ----->
##        if XnCntr == 112:
##
####            # Minimize range in variables...
####            lstFitCols = []
####            lstFitRows = []
####            for i, val in enumerate(lstThisSegmentCols):
####                meanCval = np.mean(lstThisSegmentCols)
####                #meanRval = np.mean(lst)
####                intvlC = lstThisSegmentCols[i] - meanCval
####                lstFitCols.append(lstThisSegmentCols[i] - intvlC)
##
####                if val < meanval:
####                    lstThisSegmentCols[i] = lstThisSegmentCols[i] - intvl
####                else:
####                    lstThisSegmentCols[i] = lstThisSegmentCols[i] - meanval/4
##
##            LinFit = np.polyfit(lstThisSegmentCols,lstThisSegmentRows,1)
##            m_ortho = LinFit[0]
##
##            xn_steps = np.linspace(-float(paramXnlength),float(paramXnlength), paramXnSteps)
##            fit_col_ortho = []
##            fit_row_ortho = []
##            for r in xn_steps:
##                fit_col_ortho.append(midPtCol + (float(r)/(sqrt(1 + m_ortho**2))))
##                fit_row_ortho.append((m_ortho)*(fit_col_ortho[-1]-midPtCol) + midPtRow)
##
##
##
####            coefficients = np.polyfit(lstThisSegmentCols,lstThisSegmentRows,1)
####            polynomial = np.poly1d(coefficients)
####            ys = polynomial(lstThisSegmentCols)
##
##            # plot segment with line fit...
##            plt.plot(fit_col_ortho, fit_row_ortho, 'b-')
##            plt.hold(True)
##            plt.plot(lstThisSegmentCols, lstThisSegmentRows, 'r-')
##            plt.gca().invert_yaxis()
##            plt.grid(b=True, which='major', color='b', linestyle='-')
##            plt.minorticks_on()
##            plt.title('Xn Number: %i' % (XnCntr,))
##            plt.show() # for code continuation
##
##        ## END TESTING

        # Check for zero or infinite slope...
        if m_init == 0:
            m_init = 0.0001
        elif isinf(m_init):
            m_init = 9999.0

        # Find the orthogonal slope...
        m_ortho = -1/m_init

        # Create the orthogonal line according to the designated Xn length...
        fit_row_ortho = []
        fit_col_ortho = []

        # You could have two separate Xn's, one for floodplains, one for channels (each with separate length parameters)
        # Limit to within the catchmnet boundary here
        # Also just get the elevation here as well?

        # Use np.linspace to generate the range so you can include steps smaller than 1...
        # NOTE: Just do 1 step here to give start and end pts?
        if bool_isvalley:
            xn_steps = [-float(paramXnlength),float(paramXnlength)]
        else:
            xn_steps = np.linspace(-float(paramXnlength),float(paramXnlength), paramXnSteps)

        for r in xn_steps:

            # Make sure it's not too close to vertical...
            # NOTE X-Y vs. Row-Col here...
            if (abs(m_ortho) > slopeCutoffVertical):
                fit_col_ortho.append(midPtCol)
                fit_row_ortho.append(midPtRow+r)
            else:
                fit_col_ortho.append(midPtCol + (float(r)/(sqrt(1 + m_ortho**2))))
                fit_row_ortho.append((m_ortho)*(fit_col_ortho[-1]-midPtCol) + midPtRow)

        # Save to tuple of lists...
        tplThisXnRowCols = ([],[])
        tplThisXnRowCols = (fit_row_ortho, fit_col_ortho, XnCntr, XnCntr) # the extra XnCntr is just a place-keeper (local ID)

        lst_xnrowcols.append(tplThisXnRowCols) # a list of tuples of lists (is this necessary here?)

        XnCntr = XnCntr + 1

    return lst_xnrowcols
####-----------------------------------------------------------------------------
##    # Limit Xns to within catchment boundaries...
####-----------------------------------------------------------------------------
###def trim_xns(lstThisReachXns, ShedArray, RowCnt, ColCnt, LinkNum, noDataval):
##def trim_xns(lstThisReachXns, ShedArray, LinkNum, strFileName, nodataval):
##
##    # Output...
##    lstTrimmedXns = []
##    tplXnLists = ([],[])
##
##    # Read the DEM...
##    #DEMarray = arcpy.RasterToNumPyArray(strFileName, nodata_to_value=nodataval)
##
##    for tplThisRowCol in lstThisReachXns: # each  XY list
##
##        lstTrimmedRow = []
##        lstTrimmedCol = []
##
##        XnLength = len(tplThisRowCol[0])
##
##        for Indx, StartPtCol in enumerate(tplThisRowCol[1]): # each point along a Xn
##
##            StartPtRow = tplThisRowCol[0][Indx]
##
##            EndPtRow = tplThisRowCol[0][XnLength - Indx - 1]
##            EndPtCol = tplThisRowCol[1][XnLength - Indx - 1]
##
###            testStart = ShedArray[StartPtRow,StartPtCol]
##
##            # (The numpy indices are automatically cast as int)
##            #if (ShedArray[StartPtRow,StartPtCol] == LinkNum) and (ShedArray[EndPtRow,EndPtCol] == LinkNum) and (int(StartPtCol) <= ColCnt) and (int(StartPtRow) <= RowCnt) and (ShedArray[StartPtRow,StartPtCol] != noDataval) and (ShedArray[EndPtRow,EndPtCol] != noDataval):
##            if (ShedArray[StartPtRow,StartPtCol] == LinkNum) and (ShedArray[EndPtRow,EndPtCol] == LinkNum): # and (DEMarray[StartPtRow,StartPtCol] != nodataval) and (DEMarray[EndPtRow,EndPtCol] != nodataval):
##
##                lstTrimmedRow.append(StartPtRow)
##                lstTrimmedCol.append(StartPtCol)
##
##        if len(lstTrimmedRow) > 3: # make sure they are of some minimum length
##            tplXnLists = (lstTrimmedRow,lstTrimmedCol)
##            lstTrimmedXns.append(tplXnLists)
##
##    return lstTrimmedXns
##-----------------------------------------------------------------------------
    # Trim and interpolate elevation along each Xn...
##-----------------------------------------------------------------------------
def trim_and_interpolate_xns(lstThisReachXns, ShedArray, DEMarray, LinkNum, dem_min, dem_max):

    # Output...
    lstTrimmedXns = []
    tplXnLists = ([],[],[])

    parm_minlength = 5 # pixels

    # Read the DEM...
    #DEMarray = arcpy.RasterToNumPyArray(strFileName)

    #xn_cntr = 0 # can't enumerate since it depends on Xn length

    for tplThisRowCol in lstThisReachXns: # each  XY list

##        if xn_num_test == 61:
##            print 'pause'

        lstTrimmedRow = []
        lstTrimmedCol = []

        XnLength = len(tplThisRowCol[0])
        boolCrossesOnce = True
        for Indx, StartPtCol in enumerate(tplThisRowCol[1]): # each point along a Xn

            StartPtRow = tplThisRowCol[0][Indx]

            EndPtRow = tplThisRowCol[0][XnLength - Indx - 1]
            EndPtCol = tplThisRowCol[1][XnLength - Indx - 1]

#            testStart = ShedArray[StartPtRow,StartPtCol]

            # (NOTE: The numpy indices are automatically cast as int)
            # The Xn should only cross the stream line once, at its midpoint...
            # (for testing, say the catchment array is the stream segment grid)


##            xn_midpt = int(XnLength/2)
##            # xn_midpt + 1 < Indx < xn_midpt - 1 # exclude Indx from this range (depends on cell size and distance between points along Xn!)
##            # search with a pixel block manually??
##            if ((ShedArray[StartPtRow,StartPtCol] != -9999 or ShedArray[StartPtRow-1,StartPtCol-1] != -9999
##             or ShedArray[StartPtRow+1,StartPtCol+1] != -9999 or ShedArray[StartPtRow-1,StartPtCol] != -9999
##              or ShedArray[StartPtRow+1,StartPtCol] != -9999 or ShedArray[StartPtRow-1,StartPtCol+1] != -9999
##               or ShedArray[StartPtRow,StartPtCol-1] != -9999 or ShedArray[StartPtRow,StartPtCol+1] != -9999)
##                and (Indx < xn_midpt - 5 or Indx > xn_midpt + 5)):
##                boolCrossesOnce = False
##                startIndx = Indx - 1
##
##            if boolCrossesOnce is False:
##                lstTrimmedRow.append()


            # Catchment boundary method...
            if (ShedArray[StartPtRow,StartPtCol] == LinkNum) and (ShedArray[EndPtRow,EndPtCol] == LinkNum): # and (DEMarray[StartPtRow,StartPtCol] != nodataval) and (DEMarray[EndPtRow,EndPtCol] != nodataval):

                lstTrimmedRow.append(StartPtRow)
                lstTrimmedCol.append(StartPtCol)


        tplTrimmed = ([],[])
        tplTrimmed = (lstTrimmedRow, lstTrimmedCol)
        zi = ndimage.map_coordinates(DEMarray, tplTrimmed, order=1, mode='nearest') # what order to use?

        if len(lstTrimmedRow) > parm_minlength and min(zi) >= dem_min and max(zi) <= dem_max: # make sure they are of some minimum length
            tplXnLists = (lstTrimmedRow,lstTrimmedCol,zi)
            lstTrimmedXns.append(tplXnLists)
            #xn_cntr = xn_cntr + 1


    return lstTrimmedXns
##-----------------------------------------------------------------------------
    # Interpolate elevation along each Xn...no trimming via catchment boundary!
##-----------------------------------------------------------------------------
def interpolate_xns(lstThisReachXns, DEMarray, LinkNum, dem_min, dem_max):

    # Output...
    lstTrimmedXns = []
    tplXnLists = ([],[],[])

    parm_minlength = 0 # pixels

    # Read the DEM...
    #DEMarray = arcpy.RasterToNumPyArray(strFileName)
    #xn_cntr = 0 # can't enumerate since it depends on Xn length

    for tpl_this in lstThisReachXns: # each  XY list

        tplThisRowCol = (tpl_this[0],tpl_this[1])

        zi = ndimage.map_coordinates(DEMarray, tplThisRowCol, order=1, mode='nearest') # what order to use?

        if len(zi) > parm_minlength and min(zi) >= dem_min and max(zi) <= dem_max: # make sure they are of some minimum length
            tplXnLists = tplThisRowCol + (zi,) + (tpl_this[2],)
            lstTrimmedXns.append(tplXnLists)

            #xn_cntr = xn_cntr + 1


    return lstTrimmedXns
##-----------------------------------------------------------------------------
    # Calculate distance in meters along each Xn...
##-----------------------------------------------------------------------------
def xn_distance_between_points(lstThisReachXns, DEMcellsize):
    """
        Gets the distance in meters between 2 points along a Xn
    """

    firstRow = lstThisReachXns[0][0][0]
    firstCol = lstThisReachXns[0][1][0]

    secRow = lstThisReachXns[0][0][1]
    secCol = lstThisReachXns[0][1][1]

    xn_ptdist = DEMcellsize*(hypot(firstCol - secCol,firstRow - secRow))

    return xn_ptdist

####-----------------------------------------------------------------------------
##    # Extract elevation values along Xn's...
####-----------------------------------------------------------------------------
##def interp_xnelev(lstXnRowCol, strFileName): #, dem_min, dem_max):
##
##    # Get the elevation profile along each Xn...
##    # Extract the values along the line -- this is kind of a built-in interpolation?? (makes it easy)
##    # zi = z[x.astype(np.int), y.astype(np.int)] (where z is the elevation array, x and y are row/col lists)
##
##    # Read the DEM...
##    DEMarray = arcpy.RasterToNumPyArray(strFileName)
##
##    lstXnElevs = []
##    for tplThisRowCol in lstXnRowCol:
##
##        zi = ndimage.map_coordinates(DEMarray, tplThisRowCol, order=1, mode='nearest') # what order to use?
##
####        # Make sure you're getting appropriate elevation values...
####        if min(zi) >= dem_min and max(zi) <= dem_max: # a bit of a hack
##
##        lstXnElevs.append(zi)
##
##    return lstXnElevs
##-----------------------------------------------------------------------------
    # Analyze the elevation profile of each Xn and determine metrics...
##-----------------------------------------------------------------------------
def analyze_xnelev(lst_allxns, param_ivert, this_linkno, xn_ptdist, param_ratiothreshold, param_slpthreshold):
    """
        Input:  List of elevation values at points along all Xn's.  Each input list entry
                is a tuple of all elevation values along that Xn.
                param_ratiothreshold = 1.5
                param_slpthreshold = 0.03

        Output: Metrics - Xn number, bank locations (indices), bank height, etc... channel width, for each Xn
                Tuple: (Xn num, lf_i, rt_i, bf_height)

        Procedure:
            1. Loop over Xn list
            2. Normalize Xn to zero
            3. Loop over vertical slices using a step set by param_ivert
            4. Find contiguous sets of indices for each slice
            5. Search for slope break
            6. If slope break exists, determine "bankfull" locations along Xn
    """
    ## USE NUMPY ARRAYS VS. LISTS??
    lst_bfmetrics = [] # list of tuples to contain output

    try:

        for xn_cnt, tpl_thisxn in enumerate(lst_allxns):

            # A list to store the total number of indices/blocks in a Xn...
            lst_total_cnt = []

            # Normalize elevation to zero...
            thisxn_norm = []
            thisxn_norm = tpl_thisxn[2] - np.min(tpl_thisxn[2])

##            print 'Xn: {}'.format(xn_cnt)
##
##            if xn_cnt == 58:
##                print xn_cnt
##                x = np.array([1,3])
##                test = np.diff(x)

            # Loop from zero to max(this_xn_norm) using a pre-defined vertical step (0.2 m?)...
            for this_slice in arange(0,np.max(thisxn_norm),param_ivert):

                # The indices of positives...
                gtzero_indices = np.nonzero((this_slice - thisxn_norm) > 0)[0] # Zero index get the first element of the returned tuple

                # Use funtion to check if contiguous...
                if np.size(gtzero_indices) == 0: # the first loop only

                    # get the index of the zero value...
                    lst_total_cnt.append(np.where(thisxn_norm == 0)[0])
                    prev_val = lst_total_cnt[0][0]

                elif is_contiguous(gtzero_indices):

                    # Yes, it is contiguous
                    # Save it to the total count...
                    lst_total_cnt.append(gtzero_indices)
                    prev_val = gtzero_indices[0] # just need any value from the contiguous array

                else:
                    # No, it's not contiguous
                    # Find the contiguous part of the slice...
                    tpl_parts = np.array_split(gtzero_indices,np.where(np.diff(gtzero_indices)!=1)[0]+1) # splits the contiguous elements into separate tuple elements

                    # Find the one that contains an element of the previous slice?...
    ##                if prev_val in [this_arr for this_arr in tpl_parts]: # use a list comprehension here?
                    for this_arr in tpl_parts:
                        if prev_val in this_arr[:]:
                            lst_total_cnt.append(this_arr)
                            prev_val = this_arr[0]
                            break

##                if len(lst_total_cnt) < 3:
##                    param_slpbreak = 3
##                else:
##                    # If the next slice is some percentage greater than the previous
##                    # THIS SHOULD BE IN TERMS OF DISTANCE AND NOT SLICE LENGTH
##                    #numSlices = len(lst_total_cnt)
##                    #prevSliceLen = len(lst_total_cnt[numSlices-2])
##                    thisSliceLen = len(lst_total_cnt[-1])
##                    param_slpbreak = int(round(thisSliceLen*0.43))

                ## TESTING...
                tpl_bankfullpts = find_bank_ratio_method(lst_total_cnt,param_ratiothreshold,thisxn_norm,param_slpthreshold)

##                # Check for slope break and find banks for this slice...
##                tpl_bankfullpts = find_bank_revised(lst_total_cnt,param_slpbreak,thisxn_norm)

                if tpl_bankfullpts: # test to see if there's anything in there?? THIS SEEMS LIKE KIND OF A HACK? (seems like there should be a more favorable way)
                    # Add Xn number to the output...
                    #xn_elev_norm = tpl_thisxn[2] - np.min(tpl_thisxn[2]) # normalized elevation profile
                    xn_length = len(thisxn_norm)

                    #tpl_bankfullpts = (xn_cnt,) + tpl_bankfullpts + (lst_total_cnt,) + (this_linkno,) + (tpl_bankfullpts[2] + np.min(tpl_thisxn[2]),)

                    # Bank points tuple...
                    tpl_bankfullpts = (tpl_thisxn[3],) + tpl_bankfullpts # add local ID

                    # Find bank angles...
                    tpl_bankangles = find_bank_angles(tpl_bankfullpts, lst_total_cnt, xn_length, thisxn_norm, param_ivert, xn_ptdist)

                    # Estimate bankfull area...
                    # (Bank height - xn_elev_norm[i])*xn_ptdist
                    # Round up on left, round down on right
                    bf_area = 0
                    for i in range(int(ceil(tpl_bankfullpts[1])),int(tpl_bankfullpts[2]),1):
                        bf_area = bf_area + (tpl_bankfullpts[3] - thisxn_norm[i])*xn_ptdist

                    # Channel width...
                    ch_width = (tpl_bankfullpts[2]-tpl_bankfullpts[1])*xn_ptdist

                    # Overbank ratio...
                    if (tpl_bankfullpts[2]-tpl_bankfullpts[1]) <= 0:
                        overbank_ratio = -9999.0
                    else:
                        overbank_ratio = len(lst_total_cnt[-1])/(tpl_bankfullpts[2]-tpl_bankfullpts[1])

                    # Also try area under entire Xn length relative to BF area...
                    total_xn_area = sum(thisxn_norm*xn_ptdist)
                    if bf_area <= 0:
                        total_arearatio = -9999.0
                    else:
                        total_arearatio = (total_xn_area - bf_area)/bf_area


                    tpl_metrics = tpl_bankfullpts + (lst_total_cnt,) + (this_linkno,) + (tpl_bankfullpts[3] + np.min(tpl_thisxn[2]),) + tpl_bankangles + (bf_area,) + (ch_width,) + (overbank_ratio,) + (total_arearatio,)

##                    # Output metrics tuple...       local ID      bank angles        bank height                        bank elevation                    xn area
##                    tpl_metrics = (this_linkno,) +  (xn_cnt,) + tpl_bankangles + (tpl_bankfullpts[3],) + (tpl_bankfullpts[2] + np.min(tpl_thisxn[2]),) + (bf_area,)

##                    # Output bank points tuple...
##                    tpl_bankpts = tpl_bankfullpts + (this_linkno,) + (tpl_bankfullpts[2] + np.min(tpl_thisxn[2]),)

##                    ##TESTING...
##                    if xn_cnt == 25 and this_linkno == 501:
##                        arcpy.AddMessage("bank height: " + str(tpl_bankfullpts[3]))
##                        arcpy.AddMessage("ch_width: " + str(ch_width))
##                    if xn_cnt == 98:
####                        seconddiff = np.diff(xn_elev_norm,n=2) # second derivative of elevation is curvature??
####                        print seconddiff
##                        print 'pause'

                    lst_bfmetrics.append(tpl_metrics)

                    break # no need to keep slicing here, unless we want to try for FP analysis
    ##            else:
    ##                print 'no bank!'

    except arcpy.ExecuteError:
        arcpy.AddMessage(arcpy.GetMessages(2))

##    except Exception as e:
##        arcpy.AddError('Error: analyze_xnelev()')
##        print e.message + ': analyze_xnelev()'

    return lst_bfmetrics
##-----------------------------------------------------------------------------
    #               Summarize metrics to reach via median (or whatever)
##-----------------------------------------------------------------------------
def summarize_to_reach(lst_metrics):
    """
        Input from analyze_xnelev:
            A list of: tpl_metrics = tpl_bankfullpts + (lst_total_cnt,) + (this_linkno,) + (tpl_bankfullpts[2] + np.min(tpl_thisxn[2]),) + tpl_bankangles + (bf_area,) + (ch_width,) + (overbank_ratio,) + (totarearat,)
    """

    lst_bankheight = []
    lst_lf_angle = []
    lst_rt_angle = []
    lst_bfarea = []
    lst_chanwidth = []
    lst_overbank = []
    lst_totarea = []

    try:

        linkno = lst_metrics[0][5]

        # Assemble lists for each metric...
        for this_tpl in lst_metrics:
            lst_bankheight.append(this_tpl[3])
            lst_lf_angle.append(this_tpl[7])
            lst_rt_angle.append(this_tpl[8])
            lst_bfarea.append(this_tpl[9])
            lst_chanwidth.append(this_tpl[10])
            lst_overbank.append(this_tpl[11])
            lst_totarea.append(this_tpl[12])

        bankheight = np.median(lst_bankheight)
        lf_angle = np.median(lst_lf_angle)
        rt_angle = np.median(lst_rt_angle)
        bf_area = np.median(lst_bfarea)
        chwidth = np.median(lst_chanwidth)
        overrat = np.median(lst_overbank)
        totarearat = np.median(lst_totarea)

        tpl_reachsummary = (linkno,bankheight,lf_angle,rt_angle,bf_area,chwidth,overrat,totarearat)

    except arcpy.ExecuteError:
        arcpy.AddMessage(arcpy.GetMessages(2))
        print(arcpy.GetMessages(2))

    return tpl_reachsummary
##-----------------------------------------------------------------------------
     # Add median FP width vals to median metric vals in final list to print
##-----------------------------------------------------------------------------
def assemble_final_reach_summary_list(lst_bfmetrics, lst_fpmetrics):
    """
        Input:
            bf metrics --> tpl_reachsummary = (linkno,bankheight,lf_angle,rt_angle,bf_area,chwidth,overrat,totarearat)
            fp metrics --> tpl_out = (this_linkno, fpwidtot,fpwidnet,fpmin,fpmax,fprange,fpmean,fpstd,fpsum)
    """

    try:

##            lst_out = [tpl_xn for tpl_xn in lst_xns if tpl_xn[3] == xn_num] # returns a list containing the tuple having this xn_num value in the 3 spot
##
##            thisxn_len = len(lst_out[0][1]) - 1 #  length in number of entries

        lst_output = []

        for this_bfmetric_tpl in lst_bfmetrics:
            lst_out = [tpl_fp for tpl_fp in lst_fpmetrics if tpl_fp[0] == this_bfmetric_tpl[0]]
            if len(lst_out) > 0:
                tpl_out = this_bfmetric_tpl + lst_out[0]
                lst_output.append(tpl_out)

##        # Sort the lists by LINKNO...
##        lst_metrics_sorted = sorted(lst_metrics, key=lambda x: x[0])
##        lst_fpwid_sorted = sorted(lst_fpwid, key=lambda x: x[0])
##
##        lst_output = []
##
##        # Assemble lists for each metric...
##        for this_metric_tpl in lst_metrics_sorted:
##            for this_fp_tpl in lst_fpwid_sorted:
##                if this_metric_tpl[0] == this_fp_tpl[0]:
##                    out_tpl = this_metric_tpl + (this_fp_tpl[1],)
##                    lst_output.append(out_tpl)
##                    break

    except arcpy.ExecuteError:
        arcpy.AddMessage(arcpy.GetMessages(2))
        print(arcpy.GetMessages(2))

    return lst_output
##-----------------------------------------------------------------------------
    #               Format output master Xn row/col list
##-----------------------------------------------------------------------------
# NOTE: You don't need to carry the elevation arrays all the way through, only per reach (don't keep in total list since they're not used?)
# First use zip(*lstTrimmedXnsAndElev) to separate out row/col lists from elev; only add row/col lists to total
# zip gets a tuple of lists, which was confusing the shit out of me
##                tpl_rows, tpl_cols, tpl_elev = zip(*lstTrimmedXnsAndElev)
##                tplTotalXn = ([thisLINKNO], tpl_rows, tpl_cols) # this would be better as a dictionary?
##               # tplTotalXn = (thisLINKNO, lstTrimmedXnsAndElev) # this would be better as a dictionary?
##                lstTotalXns.extend(tplTotalXn)
# OR, the old-fashioned way...
##                for r, this_tpl in enumerate(lstTrimmedXnsAndElev):
##                    tpl_add = (thisLINKNO,[0],this_tpl[1])
##                    lstTotalXns.append(tpl_add)
def format_master_xn_list(lst_input, this_linkno):
    lst_output = []

    for j, this_tpl in enumerate(lst_input):
        tpl_add = (this_linkno,this_tpl[0],this_tpl[1],this_tpl[3]) # this_tpl[3] ==> local xn id
        lst_output.append(tpl_add)

    return lst_output
##-----------------------------------------------------------------------------
    # Convert to map coordinates...
##-----------------------------------------------------------------------------
def convert_xncoords(lstRowsCols, CellSize, X_LLcoord, Y_LLcoord, ColCnt):
    """
        Converts grid cell coordinates from rows/cols to UTM

        NOTE: row ==> Y; col ==> X
        (confusing nomenclature throughout this code that needs to be considered (X/Y vs. rows/cols))

        Returns: a list of tuples in map coordinates

        Input: list of tuples of lists in array row/col and grid properties
            (each input tuple contains a Xn row/col lists)
                tpl_add = (this_linkno,this_tpl[0],this_tpl[1],j) # j ==> local xn num?

    """

    """
        XnPts(XnPt_tally).X = ThiscrossSectionsXYArray{j,1}(t)*CellSizeDem+xLowerLeftCoordDem;
        XnPts(XnPt_tally).Y = yLowerLeftCoordDem-ThiscrossSectionsXYArray{j,2}(t)*CellSizeDem+yDemSize*CellSizeDem;
    """
    # NOTE: Speed this up somehow??

    #tplMapRowCol = (,)
    lstMapRowCol = []

    for this_tpl in lstRowsCols:

        thisLINKNO = this_tpl[0]
        lstRow = this_tpl[1]
        lstCol = this_tpl[2]
        this_xn_num = this_tpl[3]

        thisMapCol = [thisCol * CellSize + X_LLcoord for thisCol in lstCol] # X
        thisMapRow = [Y_LLcoord - thisRow * CellSize + ColCnt * CellSize for thisRow in lstRow] # Y

        tplMapRowCol = (thisMapRow,thisMapCol,thisLINKNO,this_xn_num)

        lstMapRowCol.append(tplMapRowCol)

    return lstMapRowCol
##-----------------------------------------------------------------------------
    # Convert points along Xn's to row/column list...
##-----------------------------------------------------------------------------
def convert_bfpositions(lst_metrics, lst_xns, CellSize, X_LLcoord, Y_LLcoord, ColCnt, xn_ptdist):
    """
        Convert points along Xn's to row/column list

        Returns: a list of tuples in array coordinates (row/col)

        Inputs:  list of bank metric tuples
                 list of tuples of lists (row/col)

        tpl_metrics = tpl_bankfullpts + (lst_total_cnt,) + (this_linkno,) + (tpl_bankfullpts[3] + np.min(tpl_thisxn[2]),) + tpl_bankangles + (bf_area,) + (ch_width,) + (overbank_ratio,) + (total_arearatio,)

                    tpl_metrics[0]: Xn number
                    tpl_metrics[1]: left bank index height
                    tpl_metrics[2]: right bank index
                    tpl_metrics[3]: height
                    tpl_metrics[4]: lst_total_cnt
                    tpl_metrics[5]: LINKNO
                    tpl_metrics[6]: bank elevation (absolute)
                    tpl_metrics[7]: left bank angle  (degrees from vertical)
                    tpl_metrics[8]: right bank angle (degrees from vertical)
                    tpl_metrics[9]: bank full area (m2)
                    tpl_metrics[10]: channel width (m)
                    tpl_metrics[11]: overbank ratio
                    tpl_metrics[12]: ratio of area above bankfull and below total Xn length over bankfull area

    """

    tpl_metrics = ()
    lst_bfrc = []
    #total_num_xns = len(lst_xns)

    try:

        for tpl_metrics in lst_metrics:

            print(tpl_metrics[0]) # xn num

            # NOTE: metrics xn num and lst_xns xn num are not lining up??

##            if tpl_metrics[0] == 96:
##                print 'halt!'

            #    xn_cnt, lft_position, rt_position, height, total_count, linkno
            xn_num = tpl_metrics[0] # local Xn number
            lf_indx = tpl_metrics[1]
            rt_indx = tpl_metrics[2]
            this_bankheight = tpl_metrics[3]
            this_linkno = tpl_metrics[5]
            this_elev = tpl_metrics[6]
            this_chwidth = xn_ptdist * abs(lf_indx - rt_indx)
            this_lfang = tpl_metrics[7]
            this_rtang = tpl_metrics[8]
            this_bfarea = tpl_metrics[9]
            this_overbank = tpl_metrics[11]
            this_totarearat = tpl_metrics[12]

            lst_out = [tpl_xn for tpl_xn in lst_xns if tpl_xn[3] == xn_num] # returns a list containing the tuple having this xn_num value in the 3 spot

            thisxn_len = len(lst_out[0][1]) - 1 #  length in number of entries


    ##        # Plain Jane version...
    ##        lf_row = lst_xns[xn_num][0][int(lf_indx)]
    ##        lf_col = lst_xns[xn_num][1][int(lf_indx)]
    ##        rt_row = lst_xns[xn_num][0][int(rt_indx)]
    ##        rt_col = lst_xns[xn_num][1][int(rt_indx)]

            # Decimal version...
            # Left:
            dec_val, i_val = modf(lf_indx)
            i_val = int(i_val)

            i1_row = lst_out[0][1][i_val]
            i1_col = lst_out[0][2][i_val]

            if(i_val >= thisxn_len):
                i2_row = i1_row
                i2_col = i1_col
            else:
                i2_row = lst_out[0][1][i_val+1]
                i2_col = lst_out[0][2][i_val+1]

            lf_row = i1_row + dec_val*(i2_row-i1_row)
            lf_col = i1_col + dec_val*(i2_col-i1_col)

            # Right:
            dec_val, i_val = modf(rt_indx)
            i_val = int(i_val)

            if i_val >= thisxn_len: # just making sure it' not at end of Xn (?)
                rt_row = lst_out[0][1][i_val]
                rt_col = lst_out[0][2][i_val]
            else:
                i1_row = lst_out[0][1][i_val]
                i1_col = lst_out[0][2][i_val]

                i2_row = lst_out[0][1][i_val+1]
                i2_col = lst_out[0][2][i_val+1]

                rt_row = i1_row + dec_val*(i2_row-i1_row)
                rt_col = i1_col + dec_val*(i2_col-i1_col)

            lf_MapCol = lf_col * CellSize + X_LLcoord
            lf_MapRow = Y_LLcoord - lf_row * CellSize + ColCnt * CellSize

            rt_MapCol = rt_col * CellSize + X_LLcoord
            rt_MapRow = Y_LLcoord - rt_row * CellSize + ColCnt * CellSize

            # Add to output tuple...
            lst_bfrc.append((lf_MapRow,lf_MapCol,rt_MapRow,rt_MapCol,xn_num,this_linkno,this_elev, this_bankheight,this_chwidth,this_lfang,this_rtang,this_bfarea,this_overbank,this_totarearat))  # how to handle all metrics output??

    except Exception as e:
        arcpy.AddError('Error: convert_bfpositions()')
        print(e.message + ': convert_bfpositions()')

    return lst_bfrc
####-----------------------------------------------------------------------------
##    # Floodplain extent via Height Above River...
####-----------------------------------------------------------------------------
##def calculate_fp_extent(parm_bankpt_path, parm_dem_path, parm_net_path, parmRadius, parmHeight, parm_gridpath):
##    """
##        Calculates a floodplain extent grid using detrending and Height Above River (HAR)
##        Analysis adapted from the Riparian Topography Toolbox
##        (Dilts, T.E. and Yang, J. 2010. Riparian Topography Toolbox for ArcGIS 9.X (substitute your
##        version for X). University of Nevada Reno. Available at:
##        http://www.cabnr.unr.edu/weisberg/downloads
##
##        Inputs:     1. Bank Elevation Points (with ELEV field)
##                    2. Cross sections
##                    3. Elevation grid/DEM
##                    4. Streamlines (net.shp) --> for cost back link connectivity to stream
##                    5. Search radius parameter (m)
##                    6. Height threshold parameter (m)
##
##        Outputs:    1. Floodplain extent grid (.tif)
##                    2. Reach summary list?
##
##    """
##
##    lst_fpwidth_rch = []
##    parmElevFld = 'ELEV'
##
##    # Get the DEM cell size...
##    props = arcpy.GetRasterProperties_management(parm_dem_path,"CELLSIZEX")
##    cellSize = float(props.getOutput(0))
##
##    testdir = os.path.dirname(parm_bankpt_path) ## directory of file
##
##    env.workspace = os.path.dirname(parm_bankpt_path)
##
##    try:
##
##        ##------------------------------------------------------------->
##        ## Perform HAR and calculate FP grid based on input height...
##        ##------------------------------------------------------------->
##        print 'Running HAR...'
##        arcpy.AddMessage("() Kernel Density with elevation")
##        #KD_elev = KernelDensity(filename_pts, parmElevFld, cellSize, parmRadius, "SQUARE_KILOMETERS") # NOTE: FIELD NAME
##        KD_elev = KernelDensity(parm_bankpt_path, parmElevFld, cellSize, parmRadius, "SQUARE_KILOMETERS") # NOTE: FIELD NAME
##        KD_elev.save(r"in_memory\KD_elev")
##
##        # # (Step 2) Process: Kernel Density reference...
##        arcpy.AddMessage("() Kernel Density reference")
##        KD_ref = KernelDensity(parm_bankpt_path, "NONE", cellSize, parmRadius, "SQUARE_KILOMETERS")
##        KD_ref.save(r"in_memory\KD_ref")
##
##        # # (Step 3) Use CON statement here in case KD_Ref.tif has zero values!
##        arcpy.AddMessage("() CON statement")
##        KD_ref_con = Con(Raster(r"in_memory\KD_ref"),Raster(r"in_memory\KD_ref"),0.01,"VALUE > 0")
##        KD_ref_con.save(r"in_memory\KD_Ref_con")
##        arcpy.Delete_management(r"in_memory\KD_ref")
##
##        # (Step 4) Process: Divide
##        arcpy.AddMessage("() Divide to create weighted water surface elevation")
##        WeightedStreamElev = Divide(r"in_memory\KD_elev", r"in_memory\KD_ref_con")
##        WeightedStreamElev.save(r"in_memory\WeightedStreamElev")
##
##        arcpy.Delete_management(r"in_memory\KD_ref_con")
##        arcpy.Delete_management(r"in_memory\KD_elev")
##
##    	# (Step 5) Process: Minus
##    	arcpy.env.extent = parm_dem_path
##    	arcpy.AddMessage("() Subtract to create base height above river grid")
##    	HARbase = Minus(parm_dem_path, r"in_memory\WeightedStreamElev")
##    	HARbase.save(r"in_memory\HARbase")
##
##    	# (Step 6) Select only a portion of HAR grid (less than some parameter to give floodplain)
##    	arcpy.AddMessage("() Delineating Height Above River")
##    	arcpy.env.extent = parm_dem_path
##    	#HARbase = r"in_memory\HARbase.tif"
##    	FPout = Raster(r"in_memory\HARbase") < parmHeight
##    	FPout.save(r"in_memory\FPout")
##        arcpy.Delete_management(r"in_memory\HARbase")
##
##        # (Step ) Re-classify FP grid for Cost Back Link analysis using CON...
##        arcpy.AddMessage("() Reclassifying output with CON")
##        outCon = Con(FPout==1,1)
##        outConInt = Int(outCon)
##        outConInt.save(r"in_memory\FP_int")
##        arcpy.Delete_management(outCon)
##
##        # (Step ) Now run Cost Back Link tool...
##        arcpy.AddMessage("() Performing Cost Back Link...")
##        outBackLink = CostBackLink(parm_net_path, outConInt)
##        outBackLink.save(r"in_memory\FP_backlink")
##        arcpy.Delete_management(r"in_memory\FP_int")
##
##        # (Step ) Reclassify again and save...
##        arcpy.AddMessage("() Saving final floodplain grid...")
##        outCon2 = Con(outBackLink>0,1)
##        outCon2.save(parm_gridpath)  # save to: parm_gridpath
##        arcpy.Delete_management(r"in_memory\FP_backlink")
##
##    except Exception as e:
##        arcpy.AddError('Error: calculate_fp_extent()')
##        print e.message + ': calculate_fp_extent()'
##
##    return
####-----------------------------------------------------------------------------
##    # Floodplain width at each input Xn using row/col pairs and FP grid...
####-----------------------------------------------------------------------------
##def calculate_fp_width(lst_xn_rowcols, fp_grid_path, nodata_val, xnpt_dist):
##    """
##        Input Xn list is a list of tuples:
##
##            tplValley = (lstValleyXns, thisLINKNO)
##
##    """
##
##    lst_fp_width = []
##
##    # Get FP grid as numpy array...
##    FParr = arcpy.RasterToNumPyArray(fp_grid_path, nodata_to_value=nodata_val)
##
####    for tplThisRowCol in lstThisReachXns: # each  XY list
####
######        tplTrimmed = ([],[])
######        tplTrimmed = (lstTrimmedRow, lstTrimmedCol)
####        zi = ndimage.map_coordinates(DEMarray, tplThisRowCol, order=1, mode='nearest') # what order to use?
####
####        if len(zi) > parm_minlength and min(zi) >= dem_min and max(zi) <= dem_max: # make sure they are of some minimum length
####            tplXnLists = tplThisRowCol + (zi,)
####            lstTrimmedXns.append(tplXnLists)
####            #xn_cntr = xn_cntr + 1
##
##    try:
##
##        for this_tpl in lst_xn_rowcols:
##
##            thisLINKNO = this_tpl[0]
##            lstRow = this_tpl[1]
##            lstCol = this_tpl[2]
##            this_xnnum = this_tpl[3]
##
##            tplThisRowCol = ([],[])
##            tplThisRowCol = (lstRow,lstCol)
##
##            # Interpolate row/cols along FP grid...
##            zi = ndimage.map_coordinates(FParr, tplThisRowCol, order=0, mode='nearest') # what order to use?
##
##            # Loop over output and count number of nonzeros (total number * xnptdist = FP width?)
##            lst_thisxn = []
##            for cntr, this_val in enumerate(zi):
##                if this_val == 1:
##                    lst_thisxn.append(cntr)
##
##            # Get total FP width...
##            this_fpwidth = len(lst_thisxn)*xnpt_dist # len minus 1?
##
##            tpl_output = (thisLINKNO, this_xnnum, this_fpwidth)
##            lst_fp_width.append(tpl_output)
##
##    except Exception as e:
##        arcpy.AddError('Error: calculate_fp_width()')
##        print e.message + ': calculate_fp_width()'
##
##    return lst_fp_width
####-----------------------------------------------------------------------------
##    # Convert to map coordinates...
####-----------------------------------------------------------------------------
##def convert_bfcoords(lstRowsCols, CellSize, X_LLcoord, Y_LLcoord, ColCnt):
##    """
##        Converts grid cell coordinates from rows/cols to UTM
##
##        Returns: a list of tuples in map coordinates
##
##        Input: list of tuples in array row/col and grid properties
##            (each input tuple contains a Xn row/col lists)
##
##    """
##
##    """
##        XnPts(XnPt_tally).X = ThiscrossSectionsXYArray{j,1}(t)*CellSizeDem+xLowerLeftCoordDem;
##        XnPts(XnPt_tally).Y = yLowerLeftCoordDem-ThiscrossSectionsXYArray{j,2}(t)*CellSizeDem+yDemSize*CellSizeDem;
##    """
##    #arcpy.AddMessage('convert_bfcoords!')
##
##    tplMapRowCol = ()
##    lstMapRowCol = []
##
##    for tplThisRowCol in lstRowsCols:
##
##        lf_row = tplThisRowCol[0]
##        lf_col = tplThisRowCol[1]
##
##        rt_row = tplThisRowCol[2]
##        rt_col = tplThisRowCol[3]
##
##        lf_MapCol = lf_col * CellSize + X_LLcoord
##        lf_MapRow = Y_LLcoord - lf_row * CellSize + ColCnt * CellSize
##
##        rt_MapCol = rt_col * CellSize + X_LLcoord
##        rt_MapRow = Y_LLcoord - rt_row * CellSize + ColCnt * CellSize
##
##        lstMapRowCol.append((lf_MapRow, lf_MapCol, rt_MapRow, rt_MapCol, tplThisRowCol[4], tplThisRowCol[5])) # the last elements are Xn number and LINKNO
##
##    return lstMapRowCol
##-----------------------------------------------------------------------------
    #                       <<LOCAL FUNCTIONS>>
##-----------------------------------------------------------------------------
##-----------------------------------------------------------------------------
    # REVISED Search for banks via slope break and vertical slices...
##-----------------------------------------------------------------------------
def find_bank_revised(lst_total,i_slpbrk,xnelev_zero):
    """
        Compares the length of the last gtzero slice (num of indices) vs. the previous slice

        Inputs:     lst_total   - a list of 1D array slice index values
                    i_slpbrk    - the number of indices in the horizontal direction considered a slope break
                    xnelev_zero - the Xn elevation profile normalized to zero

        Output:     tpl_bfpts   - a tuple of bankfull points (left_index, right_index, height)
    """
    tpl_bfpts = ()
    this_len = len(lst_total)
    xn_len = len(xnelev_zero) - 1

   # test_Xn = xnelev_zero[23:30]
    try:

        if this_len > 1:

            # Find 'right' and 'left' ends for this and previous slices...
            this_lf_ind = lst_total[-1][0]
            this_rt_ind = lst_total[-1][-1]

            # Make sure the current slice indices are not at ends of total Xn...
##            if this_lf_ind == 0 or this_rt_ind == len(xnelev_zero):
##                print 'what to do?'


            prev_lf_ind = lst_total[this_len-2][0]
            prev_rt_ind = lst_total[this_len-2][-1]

            if prev_lf_ind - this_lf_ind >= i_slpbrk and this_rt_ind - prev_rt_ind >= i_slpbrk: # breaks on both sides

                # Search outward right and left from ends of previous slice...
                tpl_lfbank = search_left(xnelev_zero,prev_lf_ind,i_slpbrk)
                tpl_rtbank = search_right(xnelev_zero,prev_rt_ind,i_slpbrk)

                if tpl_lfbank[1] <= tpl_rtbank[1]: # left bank is the smaller

                    # Interpolate to find right bankfull...
                    rt_x2 = search_right_gt(xnelev_zero,prev_rt_ind,tpl_lfbank[1])
                    rt_x1 = rt_x2 - 1

                    rt_y1 = xnelev_zero[rt_x1]
                    rt_y2 = xnelev_zero[rt_x2]

                    if (rt_y1 == rt_y2):
                        rtbf_ind = rt_x1
                    else:
                        rtbf_ind = interp_bank(rt_x1, rt_x2, rt_y1, rt_y2, tpl_lfbank[1])

                    tpl_bfpts = (tpl_lfbank[0],rtbf_ind,tpl_lfbank[1])

                else: # right bank must be smaller or equal

                    # Find the left points surrounding the right bank elev...
                    lf_x2 = search_left_gt(xnelev_zero,prev_lf_ind,tpl_rtbank[1])
                    lf_x1 = lf_x2 + 1

                    # Interpolate to find left bankfull...
                    lf_y1 = xnelev_zero[lf_x1]
                    lf_y2 = xnelev_zero[lf_x2]

                    if(lf_y1 == lf_y2):
                        lfbf_ind = lf_x1
                    else:
                        lfbf_ind = interp_bank(lf_x1,lf_x2,lf_y1,lf_y2,tpl_rtbank[1])

                    tpl_bfpts = (lfbf_ind,tpl_rtbank[0],tpl_rtbank[1])

            elif prev_lf_ind - this_lf_ind >= i_slpbrk and this_rt_ind < xn_len: # left break

                # Find first max elev to the left...
                if xnelev_zero[prev_lf_ind] == 0: # if the previous slice is at zero height
                    tpl_lfbank = prev_lf_ind - i_slpbrk, xnelev_zero[prev_lf_ind - i_slpbrk]
                else:
                    tpl_lfbank = search_left(xnelev_zero,prev_lf_ind,i_slpbrk)

                # Now interpolate the right bankfull ...
                this_rt_ind = search_right_gt(xnelev_zero, prev_rt_ind, tpl_lfbank[1])

                rt_elev1 = xnelev_zero[this_rt_ind]
                rt_elev2 = xnelev_zero[this_rt_ind-1]

                if(rt_elev1 == rt_elev2):
                    rtbf_ind = this_rt_ind -1
                else:
                    rtbf_ind = interp_bank(this_rt_ind,this_rt_ind-1,rt_elev1,rt_elev2,tpl_lfbank[1])

                tpl_bfpts = (tpl_lfbank[0],rtbf_ind,tpl_lfbank[1])

            elif this_rt_ind - prev_rt_ind >= i_slpbrk and this_lf_ind > 0: # right break

                # Find first max elev to the right...
                if xnelev_zero[prev_rt_ind] == 0: # if the previous slice is at zero height
                    tpl_rtbank = prev_rt_ind + i_slpbrk, xnelev_zero[prev_rt_ind + i_slpbrk]
                else:
                    tpl_rtbank = search_right(xnelev_zero,prev_rt_ind,i_slpbrk)

                # Now interpolate the left bankfull...
                this_lf_ind = search_left_gt(xnelev_zero, prev_rt_ind, tpl_rtbank[1])

                lf_elev1 = xnelev_zero[this_lf_ind]
                lf_elev2 = xnelev_zero[this_lf_ind+1]

                if (lf_elev1 == lf_elev2):
                    lfbf_ind = this_lf_ind + 1
                else:
                    lfbf_ind = interp_bank(this_lf_ind,this_lf_ind+1,lf_elev1,lf_elev2,tpl_rtbank[1])

                # Create the output tuple...
                tpl_bfpts = (lfbf_ind,) + tpl_rtbank

    except arcpy.ExecuteError:
        arcpy.AddMessage(arcpy.GetMessages(2))
##    except Exception as e:
##        arcpy.AddError('Error: find_bank_revised')
##        print e.message + ': find_bank_revised()'

    return tpl_bfpts
##-----------------------------------------------------------------------------
    # REVISED Search for banks via slope break and vertical slices...
##-----------------------------------------------------------------------------
def find_bank_ratio_method(lst_total, ratio_threshold, xnelev_zero, slp_thresh):
    """
        Compares the length of the last gtzero slice (num of indices) vs. the previous slice

        Inputs:     lst_total   - a list of 1D array slice index values
                    ratio_threshold
                    xnelev_zero - the Xn elevation profile normalized to zero

        Output:     tpl_bfpts   - a tuple of bankfull points (left_index, right_index, height)
    """
    tpl_bfpts = () # output tuple
    num_slices = len(lst_total) - 1  # total number of slices, each at a height of param_vertstep
    xn_len = len(xnelev_zero) - 1 # length of Xn

    try:
        if num_slices > 2 and len(lst_total[num_slices-1]) > 2:
            top_area = len(lst_total[num_slices]) # should really include point distance but this will cancel out?
            below_area = len(lst_total[num_slices-1])

            # Check the ratio...
            this_ratio = float(top_area)/float(below_area)

            if (this_ratio > ratio_threshold): # USE THIS TO DRIVE THE BANK BREAK DETERMINATION INSTEAD??

                # Find end indices of this and of previous slice...
                prev_lf_ind = lst_total[num_slices-1][0]
                prev_rt_ind = lst_total[num_slices-1][-1]

                this_lf_ind = lst_total[num_slices][0]
                this_rt_ind = lst_total[num_slices][-1]

                # Bottom left and right for searching...
                bottom_lf = lst_total[0][0]
                bottom_rt = lst_total[0][-1]

##                # Search left for maxima...
##                lf_ind = search_left_lt(xnelev_zero,prev_lf_ind)
##                rt_ind = search_right_lt(xnelev_zero,prev_rt_ind)

                # First derivative is slope...
                lf_arr = np.array(xnelev_zero[this_lf_ind:prev_lf_ind+1])
                rt_arr = np.array(xnelev_zero[prev_rt_ind-1:this_rt_ind])
                firstdiff_left = np.diff(lf_arr)
                firstdiff_right = np.diff(rt_arr)

##                print firstdiff_right
##                print firstdiff_left

                # Set both indices to negative 1 initially...
                rt_bank_ind = -1
                lf_bank_ind = -1

                # Look for the first occurrence of a very small slope value in both directions...
                #slp_thresh = 0.03 # ? a parameter
                for r, this_rt in enumerate(firstdiff_right):
                    if this_rt < slp_thresh:
                        rt_bank_ind = r + prev_rt_ind - 1
                        break

                # Left...reverse it first?
                firstdiff_left_rev = firstdiff_left[::-1]

                #print firstdiff_left_rev # TESTING

                for r, this_lf in enumerate(firstdiff_left_rev):
                    if this_lf > -slp_thresh:
                        lf_bank_ind = prev_lf_ind - r
                        break

                # Make sure rt_bank_ind is not greater than total xn length?
                if prev_lf_ind > 0 and prev_rt_ind < xn_len:

                    # Find the smallest height of the two...
                    if rt_bank_ind > 0 and lf_bank_ind < 0: # only the right index exists

                        # Interpolate to find left bankfull...
                        bf_height = xnelev_zero[rt_bank_ind]
                        lf_x2 = search_left_gt(xnelev_zero,bottom_rt,bf_height)

                        if lf_x2 != -9999:
                            lf_x1 = lf_x2 + 1

                            lf_y1 = xnelev_zero[lf_x1]
                            lf_y2 = xnelev_zero[lf_x2]

                            if(lf_y1 == lf_y2):
                                lfbf_ind = lf_x1
                            else:
                                lfbf_ind = interp_bank(lf_x1,lf_x2,lf_y1,lf_y2,bf_height)

                            tpl_bfpts = (lfbf_ind,rt_bank_ind,bf_height)

                    elif lf_bank_ind > 0 and rt_bank_ind < 0: # only the left index exists

                        # Interpolate to find right bank index...
                        bf_height = xnelev_zero[lf_bank_ind]
                        rt_x2 = search_right_gt(xnelev_zero,bottom_lf,bf_height)

                        if rt_x2 != -9999:
                            rt_x1 = rt_x2 - 1

                            rt_y1 = xnelev_zero[rt_x1]
                            rt_y2 = xnelev_zero[rt_x2]

                            if (rt_y1 == rt_y2):
                                rtbf_ind = rt_x1
                            else:
                                rtbf_ind = interp_bank(rt_x1, rt_x2, rt_y1, rt_y2, bf_height)

                            tpl_bfpts = (lf_bank_ind,rtbf_ind,bf_height)

                    elif rt_bank_ind > 0 and lf_bank_ind > 0 and xnelev_zero[rt_bank_ind] < xnelev_zero[lf_bank_ind]: # right is smaller than left

                        # Interpolate to find left bankfull...
                        bf_height = xnelev_zero[rt_bank_ind]
                        lf_x2 = search_left_gt(xnelev_zero,bottom_rt,bf_height) # search all the way across?

                       # lf_x2 = search_left_lt(xnelev_zero, lf_bank_ind, bf_height) # find the index that's just smaller than bank height on left side FASTER?

                        if lf_x2 != -9999:
                            lf_x1 = lf_x2 + 1

                            lf_y1 = xnelev_zero[lf_x1]
                            lf_y2 = xnelev_zero[lf_x2]

                            if(lf_y1 == lf_y2):
                                lfbf_ind = lf_x1
                            else:
                                lfbf_ind = interp_bank(lf_x1,lf_x2,lf_y1,lf_y2,bf_height)

                            tpl_bfpts = (lfbf_ind,rt_bank_ind,bf_height)

                    elif rt_bank_ind > 0 and lf_bank_ind > 0 and xnelev_zero[lf_bank_ind] < xnelev_zero[rt_bank_ind]: # left is smaller than right

                        # Interpolate to find right bank index...
                        bf_height = xnelev_zero[lf_bank_ind]
                        rt_x2 = search_right_gt(xnelev_zero,bottom_lf,bf_height) # Searches all the way across channel

                        if rt_x2 != -9999:
                            rt_x1 = rt_x2 - 1

                            rt_y1 = xnelev_zero[rt_x1]
                            rt_y2 = xnelev_zero[rt_x2]

                            if (rt_y1 == rt_y2):
                                rtbf_ind = rt_x1
                            else:
                                rtbf_ind = interp_bank(rt_x1, rt_x2, rt_y1, rt_y2, bf_height)

                            tpl_bfpts = (lf_bank_ind,rtbf_ind,bf_height)

                    elif rt_bank_ind > 0 and lf_bank_ind > 0 and xnelev_zero[lf_bank_ind] == xnelev_zero[rt_bank_ind]: # they're exactly equal
                        #print 'they are the same!'
                        bf_height = xnelev_zero[lf_bank_ind]
                        tpl_bfpts = (lf_bank_ind,rt_bank_ind,bf_height)


    except arcpy.ExecuteError:
        arcpy.AddMessage(arcpy.GetMessages(2))
##    except Exception as e:
##        arcpy.AddError('Error: find_bank_revised')
##        print e.message + ': find_bank_revised()'

    return tpl_bfpts
##-----------------------------------------------------------------------------
    # Calculate angle from vertical of left and right banks...
##-----------------------------------------------------------------------------
def find_bank_angles(tpl_bfpts, lst_total_slices, xn_len, xn_elev_n, parm_ivert, xn_ptdistance):

    try:

        # How many total slices?...
        total_slices = len(lst_total_slices)

        # Use second to last slice for bottom estimate
        if total_slices > 2:

            # Interpolate to find left position along bank...
            lf_bottom_ind = lst_total_slices[1][0]

            # LEFT BANK:  Make sure we're within bounds here
            if lf_bottom_ind == 0 or lf_bottom_ind == xn_len:
                lf_angle = 0
            else:
                x1 = lf_bottom_ind-1
                x2 = lf_bottom_ind
                y1 = xn_elev_n[x1]
                y2 = xn_elev_n[x2]
                yuk = parm_ivert

                lf_bottombank_ind = interp_bank(x1,x2,y1,y2,yuk)

                if abs(lf_bottombank_ind - tpl_bfpts[1]) > 0:
                    lf_angle = atan((abs(lf_bottombank_ind - tpl_bfpts[1]))/((tpl_bfpts[3]-parm_ivert)*xn_ptdistance))*57.29578  # convert radians to degrees
                else:
                    lf_angle = 0

            # RIGHT BANK: Interpolate to find left position along bank...
            rt_bottom_ind = lst_total_slices[1][-1]

            # Make sure we're within bounds here
            if rt_bottom_ind == 0 or rt_bottom_ind == xn_len:
                rt_angle = 0
            else:
                x1 = rt_bottom_ind
                x2 = rt_bottom_ind+1
                y1 = xn_elev_n[x1]
                y2 = xn_elev_n[x2]
                yuk = parm_ivert

                rt_bottombank_ind = interp_bank(x1,x2,y1,y2,yuk)

                if abs(rt_bottombank_ind - tpl_bfpts[2]) > 0:
                    rt_angle = atan((abs(rt_bottombank_ind - tpl_bfpts[2]))/((tpl_bfpts[3]-parm_ivert)*xn_ptdistance))*57.29578  # convert radians to degrees
                else:
                    rt_angle = 0

        else: # if there's only one slice, just set it to 0? or -9999?
##                            lf_angle = -9999
##                            rt_angle = -9999
            # Use bottom slice for bank angle estimate...
            lf_bottom_ind = lst_total_slices[0][0]
            rt_bottom_ind = lst_total_slices[0][-1]

            if abs(lf_bottom_ind - tpl_bfpts[1]) > 0:
                lf_angle = atan((abs(lf_bottom_ind - tpl_bfpts[1])*xn_ptdistance)/tpl_bfpts[3])*57.29578  # convert radians to degrees
            else:
                lf_angle = 0

            if abs(rt_bottom_ind - tpl_bfpts[2]) > 0:
                rt_angle = atan((abs(rt_bottom_ind - tpl_bfpts[2])*xn_ptdistance)/tpl_bfpts[3])*57.29578 # convert radians to degrees
            else:
                rt_angle = 0

        # NOTE: For now, just set any resulting negative values to -9999, until we figure out what's going on (27Mar2015, SJL)
        if lf_angle < 0:
            lf_angle = -9999.0

        if rt_angle < 0:
            rt_angle = -9999.0

        tpl_angles = (lf_angle,rt_angle)

    except arcpy.ExecuteError:
        arcpy.AddMessage(arcpy.GetMessages(2))
        print(arcpy.GetMessages(2))

    return tpl_angles
##-----------------------------------------------------------------------------
    # Check for continuity in vertical cross section slices...
##-----------------------------------------------------------------------------
def is_contiguous(gtzero_inds):
    """
        Used by analyze_elev function
    """
    if (np.max(gtzero_inds) - np.min(gtzero_inds)) == np.count_nonzero(gtzero_inds) - 1:
        # Contiguous, continue
        #print 'Contiguous'
        bool_cont = True

    else:
        # Not contiguous, trim off the extras
        #print 'Not contiguous'
        bool_cont = False

    return bool_cont
##-----------------------------------------------------------------------------
    # Interpolate to find positions of right/left bank...
##-----------------------------------------------------------------------------
def interp_bank(x1,x2,y1,y2,y_uk):

    x_uk = (((x2 - x1)*(y_uk - y1))/(y2-y1)) + x1;

    return x_uk
##-----------------------------------------------------------------------------
    # Search Xn outward to the right to find maxima...
##-----------------------------------------------------------------------------
def search_right(xnelev,prev_ind,i_brk):

    bank_inds = 0,0

    # Search outward from end of previous slice...
    max_elev = xnelev[prev_ind]

    for i in range(prev_ind+1,len(xnelev),1):

        if xnelev[i] <= max_elev: # this assumes there is a local maxima
            bank_inds = i-1, max_elev
            break
        elif i - prev_ind == i_brk:
            bank_inds = i, xnelev[i]
            break
        elif i == len(xnelev): # end of xn reached
            bank_inds = i, xnelev[i]
        else:
            max_elev = xnelev[i]


    return bank_inds
##-----------------------------------------------------------------------------
    # Search Xn outward to the left to find maxima...
##-----------------------------------------------------------------------------
def search_left(xnelev,prev_ind,i_brk):

    bank_inds = 0,0

    # Search outward from end of previous slice...
    max_elev = xnelev[prev_ind] # what about when max_elev = 0?

    # NOTE: It's not looping all the way to zero?? (stopping at i=1)
    # Range is a step, not actual indices


    for i in range(prev_ind-1,0,-1):

        if xnelev[i] <= max_elev: # this assumes a local maxima
            bank_inds = i+1, max_elev
            break
        elif prev_ind - i == i_brk: # break found according to i_brk
            bank_inds = i, xnelev[i]
            break
        elif prev_ind == i_brk:
            bank_inds = 0, xnelev[0]
        else:
            max_elev = xnelev[i]


    return bank_inds
##-----------------------------------------------------------------------------
    # Search Xn outward to the left to find the first point greater than the right bank...
##-----------------------------------------------------------------------------
def search_left_gt(xnelev,prev_ind,rt_bf):

    # Search outward from end of previous slice...

    for i in range(prev_ind,0,-1):

        if xnelev[i] > rt_bf:
            bank_ind = i
            break
        else: # flag it so you can skip this one
            bank_ind = -9999

    return bank_ind
##-----------------------------------------------------------------------------
    # Search Xn outward to the right to find the first point greater than the left bank...
##-----------------------------------------------------------------------------
def search_right_gt(xnelev,prev_ind,lf_bf):

    # Search outward from end of previous slice...
    for i in range(prev_ind+1,len(xnelev),1):

        if xnelev[i] > lf_bf:
            bank_ind = i
            break
        else: # flag it so you can skip this one
            bank_ind = -9999

    return bank_ind
##-----------------------------------------------------------------------------
    # Search Xn outward to the left to find the first point less than the previous point (find the first local maxima)...
##-----------------------------------------------------------------------------
def search_left_lt(xnelev,prev_ind, bf_h):

    # Search outward from end of previous slice...

    for i in range(prev_ind,0,-1):

        if xnelev[i] < xnelev[i+1]:
            bank_ind = i + 1
            break
        else:
            bank_ind = -1 # just a flag

    return bank_ind
##-----------------------------------------------------------------------------
    # Search Xn outward to the right to find the first point greater than the left bank...
##-----------------------------------------------------------------------------
def search_right_lt(xnelev,prev_ind):

    # Search outward from end of previous slice...
    for i in range(prev_ind,len(xnelev),1):

        if xnelev[i] < xnelev[i-1]:
            bank_ind = i
            break
        else:
            bank_ind = -1 # just a flag

    return bank_ind
#### TESTING...
##def find(a, predicate, chunk_size=1024):
##    """
##    Find the indices of array elements that match the predicate.
##
##    Parameters
##    ----------
##    a : array_like
##        Input data, must be 1D.
##
##    predicate : function
##        A function which operates on sections of the given array, returning
##        element-wise True or False for each data value.
##
##    chunk_size : integer
##        The length of the chunks to use when searching for matching indices.
##        For high probability predicates, a smaller number will make this
##        function quicker, similarly choose a larger number for low
##        probabilities. (default is 1024 - Sam)
##
##    Returns
##    -------
##    index_generator : generator
##        A generator of (indices, data value) tuples which make the predicate
##        True.
##
##    See Also
##    --------
##    where, nonzero
##
##    Notes
##    -----
##    This function is best used for finding the first, or first few, data values
##    which match the predicate.
##
##    Examples
##    --------
##    >>> a = np.sin(np.linspace(0, np.pi, 200))
##    >>> result = find(a, lambda arr: arr > 0.9)
##    >>> next(result)
##    ((71, ), 0.900479032457)
##    >>> np.where(a > 0.9)[0][0]
##    71
##
##
##    """
##    if a.ndim != 1:
##        raise ValueError('The array must be 1D, not {}.'.format(a.ndim))
##
##    i0 = 0
##    chunk_inds = chain(xrange(chunk_size, a.size, chunk_size),
##                 [None])
##
##    for i1 in chunk_inds:
##        chunk = a[i0:i1]
##        for inds in izip(*predicate(chunk).nonzero()):
##            yield (inds[0] + i0, ), chunk[inds]
##        i0 = i1
##-----------------------------------------------------------------------------
    #                 <<SHAPEFILE WRITING FUNCTIONS>>
##-----------------------------------------------------------------------------
##def write_xn_shp(lst_xnpoints, str_path):
##    import shapefile
##
##    print 'Writing Valley Xn line shapefile...'
##    arcpy.AddMessage('Writing Xn line shapefile...')
##    w = shapefile.Writer(shapefile.POLYLINE)
##
####    lstThisX = []
####    lstThisY = []
##
##    # Add a field...
##    w.field('GLOBALID')
##    w.field('LINKNO')
##    w.field('LOCALID')
##
##    for GlobalXnID, tpl_this in enumerate(lst_fpxns):
##        # NOTE: shapefile takes XY coords, not Row/Col
##        lstX = tpl_this[1]
##        lstY = tpl_this[0]
##
##        startPt =[lstX[0],lstY[0]]
##        stopPt =[lstX[-1],lstY[-1]]
##
##        w.poly(parts=[[startPt,stopPt]], shapeType=shapefile.POLYLINE)
##        w.record(GLOBALID=GlobalXnID,LINKNO=tpl_this[2],LOCALID=tpl_this[3])
##
####        for r, thisX in enumerate(lstX):
####            thisY = lstY[r]
####            w.point(thisX,thisY)
####            w.record(GLOBALID=GlobalXnID,LINKNO=tpl_this[2],LOCALID=tpl_this[3])
##
##    #w.save(str_path + '/Py_XnPoints')
##    w.save(str_path)
##
##    return
##-----------------------------------------------------------------------------
def write_valley_xn_lines(lst_fpxns, str_path, str_spatref):
    """
        Input: tplMapRowCol = (thisMapRow,thisMapCol,thisLINKNO,this_xn_num)

            OR tpl_output = (thisLINKNO, this_xnnum, tplThisRowCol, this_fp_min, this_fp_max, this_fp_range, this_fp_mean, this_fp_std, this_fp_sum)

    """
    import shapefile

    print('Writing Valley Xn line shapefile...')
    arcpy.AddMessage('Writing Valley Xn line shapefile...')
    w = shapefile.Writer(shapefile.POLYLINE)

##    lstThisX = []
##    lstThisY = []

    # Add a field...
    w.field('GLOBALID')
    w.field('LINKNO')
    w.field('LOCALID')

    for GlobalXnID, tpl_this in enumerate(lst_fpxns):
        # NOTE: shapefile takes XY coords, not Row/Col
        lstX = tpl_this[1]
        lstY = tpl_this[0]

        startPt =[lstX[0],lstY[0]]
        stopPt =[lstX[-1],lstY[-1]]

        w.poly(parts=[[startPt,stopPt]], shapeType=shapefile.POLYLINE)
        w.record(GLOBALID=GlobalXnID,LINKNO=tpl_this[2],LOCALID=tpl_this[3])

##        for r, thisX in enumerate(lstX):
##            thisY = lstY[r]
##            w.point(thisX,thisY)
##            w.record(GLOBALID=GlobalXnID,LINKNO=tpl_this[2],LOCALID=tpl_this[3])

    #w.save(str_path + '/Py_XnPoints')
    w.save(str_path)

    # also write the projection file...
##    tpl_ext = os.path.splitext(str_path)
##    f = open(str(tpl_ext[0]) + ".prj", 'w')
##    f.write(str_spatref)
##    f.close()
    write_prj_file(str_path, str_spatref)

    return
##-----------------------------------------------------------------------------
def write_bankpts_shp(lst_bfpoints, str_path, str_spatref):
##    arcpy.AddMessage('    Hey!')

##    # lst_bfpoints contains...
##    lst_bfrc.append((lf_MapRow,lf_MapCol,rt_MapRow,rt_MapCol,xn_num,this_linkno,this_elev,this_chwidth,this_lfang,this_rtang))

    import shapefile

    try:
        arcpy.AddMessage('Writing channel bank points shapefile...')
        print('Writing bank points shapefile...')
        w = shapefile.Writer(shapefile.POINT)

        lstThisX = []
        lstThisY = []

        # Add a field...
        w.field('LINKNO')
        w.field("LOCALID")
##        w.field("GLOBALID")
        w.field("ELEV","F",10,5)
##        w.field("CHWID","F",10,5)
##        w.field("LFANG","F",10,5)
##        w.field("RTANG","F",10,5)

##        gloID = 0
##        lst_prevLocal = []
##        prevGlobal = 0
##        thisGlobal = 0

        #                      0          1          2          3         4          5          6            7               8            9           10          11            12               13
        # lst_bfrc.append((lf_MapRow, lf_MapCol, rt_MapRow, rt_MapCol, xn_num, this_linkno, this_elev, this_bankheight, this_chwidth, this_lfang, this_rtang, this_bfarea, this_overbank, this_totarearat))

        for indx, tplrowcol in enumerate(lst_bfpoints):


            # NOTE: shapefile takes XY coords, not Row/Col
            w.point(tplrowcol[1],tplrowcol[0]) # left
            w.record(LINKNO=tplrowcol[5],LOCALID=tplrowcol[4],ELEV=float(tplrowcol[6])) #,CHWID=float(tplrowcol[7]),LFANG=float(tplrowcol[8]),RTANG=float(tplrowcol[9]))
            w.point(tplrowcol[3],tplrowcol[2]) # right
            w.record(LINKNO=tplrowcol[5],LOCALID=tplrowcol[4],ELEV=float(tplrowcol[6])) #,CHWID=float(tplrowcol[7]),LFANG=float(tplrowcol[8]),RTANG=float(tplrowcol[9]))

           # GLOBALID = XNID

        #w.save(str_path + '/Py_BF_Points')
        w.save(str_path)

        # also write the projection file...
##        tpl_ext = os.path.splitext(str_path)
##        f = open(str(tpl_ext[0]) + ".prj", 'w')
##        f.write(str_spatref.replace('"', "'"))
##        f.close()
        write_prj_file(str_path, str_spatref)

    except arcpy.ExecuteError:
        arcpy.AddMessage(arcpy.GetMessages(2))
        print(arcpy.GetMessages(2) + ' --> Writing bank points shapefile')

    return
##-----------------------------------------------------------------------------
def write_prj_file(str_filepath, str_spref):

    try:

        tpl_ext = os.path.splitext(str_filepath)
        f = open(str(tpl_ext[0]) + ".prj", 'w')
        str_spref = str_spref.replace("'", '"')
        f.write(str_spref)
        f.close()

    except arcpy.ExecuteError:
        arcpy.AddMessage(arcpy.GetMessages(2))
        print(arcpy.GetMessages(2))

    return
##-----------------------------------------------------------------------------
def write_summary_file(lst_input, str_path, str_filename):

    try:

        str_name = os.path.splitext(str_filename)[0]
        str_outname = "\ReachSummaryOutput_" + str_name + ".txt"

        if lst_input:
            arcpy.AddMessage('Writing reach summary file...')
            f = open(str(str_path) + str_outname, 'w')
            f.write('LINKNO,BNKHT,LFANG,RTANG,BAREA,CHWID,OVERRAT,TOTRAT,LINKNO,FPWIDTOT,FPWIDNET,FPMIN,FPMAX,FPRANGE,FPMEAN,FPSTD,FPSUM\n')
            for tpl_out in lst_input:
                line = ','.join(str(x) for x in tpl_out)
                f.write(line + '\n')
            f.close()
        else:
            arcpy.AddError('No reach summary file written!')

    except arcpy.ExecuteError:
        arcpy.AddMessage(arcpy.GetMessages(2))
        print(arcpy.GetMessages(2))

    return
####-----------------------------------------------------------------------------
##def write_channel_xn_lines2(lst_xnlines, str_linepath, lst_bfpoints, str_ptpath, lst_fp_xnmetrics, str_spatref, lst_uniqueids):
##
##    try:
##
##        for this_linkno in lst_uniqueids:
##
##            lst_out = [list(tpl_fp) for tpl_fp in lst_fpmetrics if tpl_fp[0] == this_linkno]
##
##
##
##    except arcpy.ExecuteError:
##        arcpy.AddMessage(arcpy.GetMessages(2))
##        print arcpy.GetMessages(2)
##
##    return
##-----------------------------------------------------------------------------
def write_channel_xn_lines(lst_xnlines, str_linepath, lst_bfpoints, str_ptpath, lst_fp_xnmetrics, str_spatref):
    """
        Input: tplMapRowCol = (thisMapRow,thisMapCol,thisLINKNO,this_xn_num)

    """
    import shapefile # NOTE: shapefile takes XY coords, not Row/Col

    print('Writing Channel Xn and Metrics Shapefile...')
    arcpy.AddMessage('Writing Channel Xn shapefile with metrics...')

    #NOTE: Write channel xns here using bankpt metrics and fp metric lists??

    try:

        # Line setup...
        wLine = shapefile.Writer(shapefile.POLYLINE)
        wLine.field('LINKNO')
        wLine.field('LOCALID')
        wLine.field("BNKHT","F",10,5)
        wLine.field("CHWID","F",10,5)
        wLine.field("LFANG","F",10,5)
        wLine.field("RTANG","F",10,5)
        wLine.field("BAREA","F",10,5)
        wLine.field("OVERRATIO","F",10,5)
        wLine.field("AREARATIO","F",10,5)
        wLine.field("FPWIDTOT","F",10,5)
        wLine.field("FPWIDNET","F",10,5)
        wLine.field("FPMIN","F",10,5)
        wLine.field("FPMAX","F",10,5)
        wLine.field("FPRANGE","F",10,5)
        wLine.field("FPMEAN","F",10,5)
        wLine.field("FPSTD","F",10,5)
        wLine.field("FPSUM","F",10,5)

##        wFPxn = shapefile.Writer(shapefile.POLYLINE)
##        wFPxn.field(')

##        # Points setup...
##        wPt = shapefile.Writer(shapefile.POINT)
##        wPt.field("LINKNO")
##        wPt.field("LOCALID")
##        wPt.field("GLOBALID")
##        wPt.field("ELEV","F",10,5)


        pt_cntr = 0
        fp_cntr = 0

        # Loop the Xn line list...
        for GlobalXnID, tpl_this in enumerate(lst_xnlines): # this assumes lst_xnlines is the longest, which is not always the case

            # Initialize output metrics...
            pt_bnkht = -9999.0
            pt_chwid = -9999.0
            pt_lfang = -9999.0
            pt_rtang = -9999.0
            pt_bfarea = -9999.0
            pt_overrat = -9999.0
            pt_arearat = -9999.0
            fp_wid_tot = -9999.0
            fp_wid_net = -9999.0
            fp_min = -9999.0
            fp_max = -9999.0
            fp_range = -9999.0
            fp_mean = -9999.0
            fp_std = -9999.0
            fp_sum = -9999.0

            # Channel Xn Lines ---------------------------------------->
            lstX = tpl_this[1]
            lstY = tpl_this[0]

            startPt =[lstX[0],lstY[0]]
            stopPt =[lstX[-1],lstY[-1]]

            line_localID = tpl_this[3]
            line_linkno = tpl_this[2]

            # lst_fp_xnmetrics

            wLine.poly(parts=[[startPt,stopPt]], shapeType=shapefile.POLYLINE)
            #wLine.record(GLOBALID=GlobalXnID,LINKNO=line_linkno,LOCALID=line_localID)

            #                      0          1          2          3         4          5          6            7               8            9           10          11            12               13
##            # lst_bfrc.append((lf_MapRow, lf_MapCol, rt_MapRow, rt_MapCol, xn_num, this_linkno, this_elev, this_bankheight, this_chwidth, this_lfang, this_rtang, this_bfarea, this_overbank, this_totarearat))
##            if pt_cntr < len(lst_bfpoints):
##                tpl_pt = lst_bfpoints[pt_cntr]
##                pt_localID = tpl_pt[4]
##                pt_linkno = tpl_pt[5]
##
##            #                    0         1       2        3             4              5              6              7            8              9           10           11
##            # tpl_output = (thisLINKNO, lstRow, lstCol, this_xnnum, this_fpwidth, this_fpwidth_net, this_fp_min, this_fp_max, this_fp_range, this_fp_mean, this_fp_std, this_fp_sum)
##            if fp_cntr < len(lst_fp_xnmetrics):
##                tpl_fp = lst_fp_xnmetrics[fp_cntr]
##                fp_localID = tpl_fp[3]
##                fp_linkno = tpl_fp[0]

            # Bank point metrics ---------------------------------------->
            # Use list comprehensions here instead!! (These could be nested?) THERE IS PROBABLY A BETTER AND FASTER WAY TO DO THIS!!
            # ie: lst_out = [list(tpl_fp) for tpl_fp in lst_fpmetrics if tpl_fp[0] == this_linkno]

            # Get a list of bank points for this linkno...
            lst_pt_linkno = [list(tpl_pt) for tpl_pt in lst_bfpoints if tpl_pt[5] == line_linkno]

            # Now find the corresponding local ID along that LINKNO...
            lst_pt_localid = [list(tpl_pt) for tpl_pt in lst_pt_linkno if tpl_pt[4] == line_localID]

            if (len(lst_pt_localid) > 0):
                # Get point variables here...
                tpl_pt = lst_pt_localid[0]
                pt_bnkht = float(tpl_pt[7])
                pt_chwid = float(tpl_pt[8])
                pt_lfang = float(tpl_pt[9])
                pt_rtang = float(tpl_pt[10])
                pt_bfarea = float(tpl_pt[11])
                pt_overrat = float(tpl_pt[12])
                pt_arearat = float(tpl_pt[13])

            # FP metrics ---------------------------------------->
            # Get a list of fp for this linkno...
            lst_fp_linkno = [list(tpl_fp) for tpl_fp  in lst_fp_xnmetrics if tpl_fp[0] == line_linkno]

            # Now find the corresponding local ID along that LINKNO...
            lst_fp_localid = [list(tpl_fp) for tpl_fp in lst_fp_linkno if tpl_fp[3] == line_localID]

            if (len(lst_fp_localid) > 0):
                # Get fp variables here...
                tpl_fp = lst_fp_localid[0]

                fp_wid_tot = float(tpl_fp[4])
                fp_wid_net = float(tpl_fp[5])
                fp_min = float(tpl_fp[6])
                fp_max = float(tpl_fp[7])
                fp_range = float(tpl_fp[8])
                fp_mean = float(tpl_fp[9])
                fp_std = float(tpl_fp[10])
                fp_sum = float(tpl_fp[11])

            # Set them all to default initially...
##        wLine.field("BNKHT","F",10,5)
##        wLine.field("CHWID","F",10,5)
##        wLine.field("LFANG","F",10,5)
##        wLine.field("RTANG","F",10,5)
##        wLine.field("BFAREA","F",10,5)
##        wLine.field("OVERRATIO","F",10,5)
##        wLine.field("AREARATIO","F",10,5)



##            # When channel xns and valley xns line up...
##            if line_linkno == fp_linkno and line_localID == fp_localID:
##
##                fp_wid_tot = float(tpl_fp[4])
##                fp_wid_net = float(tpl_fp[5])
##                fp_min = float(tpl_fp[6])
##                fp_max = float(tpl_fp[7])
##                fp_range = float(tpl_fp[8])
##                fp_mean = float(tpl_fp[9])
##                fp_std = float(tpl_fp[10])
##                fp_sum = float(tpl_fp[11])
##
##                fp_cntr = fp_cntr + 1
##
##            if line_linkno == pt_linkno and line_localID == pt_localID: # if Xn and bank points match up
##
##                # Get point variables here...
##                pt_bnkht = float(tpl_pt[7])
##                pt_chwid = float(tpl_pt[8])
##                pt_lfang = float(tpl_pt[9])
##                pt_rtang = float(tpl_pt[10])
##                pt_bfarea = float(tpl_pt[11])
##                pt_overrat = float(tpl_pt[12])
##                pt_arearat = float(tpl_pt[13])
##
##                pt_cntr = pt_cntr + 1

                # NOTE: this gets handled earlier in calculate_fp_extent()
##            # Subtract out channel width from FP width...
##            fp_wid = fp_wid - pt_chwid
##            if fp_wid < 0:
##                fp_wid = 0

            wLine.record(GLOBALID=GlobalXnID,LINKNO=line_linkno,LOCALID=line_localID,
                BNKHT=pt_bnkht,CHWID=pt_chwid,LFANG=pt_lfang,
                RTANG=pt_rtang,BAREA=pt_bfarea,OVERRATIO=pt_overrat,AREARATIO=pt_arearat,
                FPWIDTOT=fp_wid_tot,FPWIDNET=fp_wid_net,FPMIN=fp_min,FPMAX=fp_max,FPRANGE=fp_range,FPMEAN=fp_mean,FPSTD=fp_std,FPSUM=fp_sum)

        wLine.save(str_linepath)
        #wPt.save(str_ptpath)

        # also write the projection file...
##        tpl_ext = os.path.splitext(str_linepath)
##        f = open(str(tpl_ext[0]) + ".prj", 'w')
##        f.write(str_spatref)
##        f.close()
        write_prj_file(str_linepath, str_spatref)

    except arcpy.ExecuteError:
        arcpy.AddMessage(arcpy.GetMessages(2))
        print(arcpy.GetMessages(2) + ' --> Writing Channel Xn lines and Metrics')

    return
####-----------------------------------------------------------------------------
##def median_list(lst_input):
##    median_val = 0
##
##    try:
##
##        lst_input.sort()
##        median_val = lst_input[len(lst_input)/2]
##
##    except arcpy.ExecuteError:
##        arcpy.AddMessage(arcpy.GetMessages(2))
##        print arcpy.GetMessages(2) + ' --> median val of list function'
##
##    return median_val
####-----------------------------------------------------------------------------
    #                     <<PLOTTING FUNCTIONS>>
##-----------------------------------------------------------------------------
##-----------------------------------------------------------------------------
    # Plot the elevation profile of an individual Xn with added stuff...
##-----------------------------------------------------------------------------
def plot_xn_profile_full(xn_num, lst_metrics, lst_xn, i_step, xn_ptdist):

    # Get the index where lst_metrics[0] == xn_num
    #[indx for indx, this_tpl in enumerate(lst_metrics) if this_tpl[0]==xn_num]

    # Get the index of the Xn elevation...
##    for r, this_tpl in enumerate(lst_xn):
##        if this_tpl == xn_num:
##            xn_indx = r
##            break
    boolYes = False
    # Get the index of the metrics...
    for r, this_tpl in enumerate(lst_metrics):
        if this_tpl[0] == xn_num:
            indx = r
            boolYes = True
            break

    # Create the distance list based on spacing between points...
    lst_xdist = [0]
    #test1 = len(lst_metrics[0][5])
    for r in range(1,len(lst_xn[xn_num][2])):
        lst_xdist.append(lst_xdist[-1] + xn_ptdist)

    # Xn profile...
    plt.plot(lst_xdist,(lst_xn[xn_num][2]-min(lst_xn[xn_num][2])), 'b-s') # normalize elevation
    plt.hold(True)

    if boolYes:
        # Left bankfull point...(multiply by xn_ptdist to convert to meters from indices)
        plt.plot(xn_ptdist*lst_metrics[indx][1],lst_metrics[indx][3], 'c*')
        # Right bankfull point...
        plt.plot(xn_ptdist*lst_metrics[indx][2],lst_metrics[indx][3], 'c*')


        # Add Xn area points?...
        i_vertcum = 0

        #for this_arr in lst_areapts:
        for this_arr in lst_metrics[indx][4]:
            y_arr = np.zeros(np.shape(this_arr))
            y_arr[:] = i_vertcum
            plt.plot(xn_ptdist*this_arr, y_arr, marker="o")
            i_vertcum = i_vertcum + i_step


    plt.grid(b=True, which='major', color='b', linestyle='-')
    plt.minorticks_on()
    plt.title('Xn Number: %i' % (xn_num,))
    plt.xlabel('Distance (m)')
    plt.ylabel('Height (m)')
    plt.show() # for code continuation

    return
##-----------------------------------------------------------------------------
    # Plot the elevation profile of an individual Xn only...
##-----------------------------------------------------------------------------
def plot_xn_profile_only(xn_profile, xn_num):

    # Xn profile...
    plt.plot(xn_profile, 'b-')

    plt.grid(b=True, which='major', color='b', linestyle='-')
    plt.minorticks_on()
    plt.title('Xn Number: %i' % (xn_num,))
    plt.show() # for code continuation

    return
## DEPRECATED FUNCTIONS...
####-----------------------------------------------------------------------------
##    # Plot cross sectional area of an individual Xn...
####-----------------------------------------------------------------------------
##def plot_xn_area(lst_allslices, i_vert): #, xnelev_norm):
##
####    fig = plt.figure()
####    ax = fig.add_subplot(111)
##    i_vertcum = i_vert
##
##    for this_arr in lst_allslices:
##        y_arr = np.zeros(np.shape(this_arr))
##        y_arr[:] = i_vertcum
##        plt.plot(this_arr, y_arr, marker="o")
##        i_vertcum = i_vertcum + i_vert
##
####    plt.grid(b=True, which='major', color='b', linestyle='-')
####    plt.minorticks_on()
####    plt.show()
##
##    return





