#-------------------------------------------------------------------------------
# editor: by Adrian Wiemgan 2020-09-22 
# revisions:
# 	- converted from python 2.4.x to 3.x using python-modernize -w scriptname.py
#   - replaced all tabs with 4 spaces
# notes: 
# 	- these changes allow the tool to be compatible with ArcGIS Pro 2.x and python 3.x
#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      sjlamont
#
# Created:     06/04/2015
# Copyright:   (c) sjlamont 2015
# Licence:     <your licence>
#-------------------------------------------------------------------------------
from __future__ import absolute_import
from __future__ import print_function
import arcpy
import funcs

def reach_loop(tpl_input):

    """
        lst_filenames = [strDEMFileName, strFDRFileName, strStartPtsFileName, strWFileName]

        lst_parameters = [parm_iXnGap, parm_iXnFit, parm_iXnLength, parm_vXnGap, parm_vXnFit, parm_vXnLength, parm_iVert, parm_ratioThresh, parm_slpThresh, parm_netshp_path, parm_fpgrid_path, NoDataVal, parmXnPtDist]

        tpl_reachloop_input = (lst_props, lst_filenames, lst_LINKNOs_to_Run, lst_parameters)

    """

    try:

        lst_props = tpl_input[0]
        lst_fnames = tpl_input[1]
        lst_linknos_to_run = tpl_input[2]
        lst_parms = tpl_input[3]

        # Get filenames...
        str_demfilename = lst_fnames[0]
        str_fdrfilename = lst_fnames[1]
        str_startptsfilename = lst_fnames[2]
        str_wfilename = lst_fnames[3]

        # Get parameters...
        parm_ixngap = lst_parms[0]
        parm_ixnfit = lst_parms[1]
        parm_ixnlength = lst_parms[2]
        parm_vxngap = lst_parms[3]
        parm_vxnfit = lst_parms[4]
        parm_vxnlength = lst_parms[5]

        parm_ivert = lst_parms[6]
        parm_ratiothresh = lst_parms[7]
        parm_slpthresh = lst_parms[8]
        parm_net_path = lst_parms[9]
        parm_fp_path = lst_parms[10]
        no_data_val = lst_parms[11]
        parm_xnptdist = lst_parms[12]
        parm_bf_path = lst_parms[13]

        parm_xnptdist_valley = 2.0 # parm_xnptdist? (faster?) testing to see the effect this has on reading elevation along FP

        # Get properties...
        DEM_RowCount = lst_props[0]
        DEM_CellSizeX = lst_props[1]
        DEM_ExtentLeft = lst_props[2]
        DEM_ExtentBottom = lst_props[3]
        DEM_minVal = lst_props[4]
        DEM_maxVal = lst_props[5]
        DEMspatRef = lst_props[6]

        # Convert properties from unicode to float...
        DEM_ExtentBottom = float(DEM_ExtentBottom)
        DEM_RowCount = float(DEM_RowCount)
        DEM_CellSizeX = float(DEM_CellSizeX)
        DEM_ExtentLeft = float(DEM_ExtentLeft)

        arcpy.AddMessage('Getting unique LINKNOs...')
        lstLINKNOs = []
        lstLINKNOs = funcs.get_linknos(str_startptsfilename)

        arcpy.AddMessage('Getting channel initiation points...')
        #print '  <<getting start points>>'
        lstStartPts = [] # a list of (row,col,linkno) tuples
        lstStartPts = funcs.get_startpts(lstLINKNOs, str_startptsfilename, lst_linknos_to_run, no_data_val)

        arcpy.AddMessage('Building reach coordinates...')
        lstReachCoords = [] # a list of tuples of lists plus LinkNum (row[],col[],linkno)
        lstReachCoords = funcs.get_reachcoords(lstStartPts, str_fdrfilename, str_wfilename)  # Is the catchment grid really needed here??

        # OR, LOOP over the reaches here??
        # 1. Build Xn's for this reach
        # 2. Trim those sections within catchment boundaries
        # 3. Analyze elevation profile

        # NOTE: This is not needed unless you're trimming the Xn's via catchment boundary
##            #  Will have to read DEM and W grids here OR read inside function every iteration
##            # Get catchment array...
##            w_array= arcpy.RasterToNumPyArray(strWFileName) #, nodata_to_value=NoDataVal) # Is it slower to add the NoDataVal? not much

        DEM_array = arcpy.RasterToNumPyArray(str_demfilename)

        lstTotalXns = [] # Master list of tuples of all reach rows and cols and elevations
        lstTotalValleyXns = []
        lstTotalBankMetrics = [] #  master list of returned bank metrics for all reaches
        lst_TotalMetricSummary = []

        ## Reach Loop--------------------------------------------------------->
        # Progress bar...DOES THIS COST ANYTHING?
        arcpy.SetProgressor('step','Calculating channel geometry metrics for each stream reach...',0,len(lstLINKNOs),1)

        #arcpy.AddMessage('Processing Reaches:  ')
        arcpy.AddMessage('Running bank detection and channel metric analysis...')
        for tplThisReach in lstReachCoords:

            # Initialize lists...
            lstReachRows = []
            lstReachCols = []

            # Get the row/cols lists and link num for this reach...
            lstReachRows = tplThisReach[0]
            lstReachCols = tplThisReach[1]
            thisLINKNO = tplThisReach[2]
            print('  Link Num: {}...'.format(thisLINKNO))
            #arcpy.AddMessage('Reach Num: {}'.format(thisLINKNO))

            # Call the Build Xn's for this reach...
            lstReachXns = [] # list of tuples of lists of XY points for Xn's
            lstReachXns = funcs.buildxns_fromcoords(lstReachRows, lstReachCols, parm_ixngap, parm_ixnfit, parm_ixnlength, DEM_CellSizeX, parm_xnptdist, False)

            lstValleyXns = [] # list of tuples of lists of XY points for Xn's
            lstValleyXns = funcs.buildxns_fromcoords(lstReachRows, lstReachCols, parm_vxngap, parm_vxnfit, parm_vxnlength, DEM_CellSizeX, parm_xnptdist_valley, False)

            # Limit the Xns to stay within the watershed here...
            # NOTES:
            # IS IT BETTER TO REPEATEDLY PASS THE BIG RASTER ARRAYS OR REPEATEDLY GET THEM WITHIN THE FUNCTION(S)??  Memory concerns holding on to the big arrays
            # I guess you could have 2 reach loops so this could be in a separate function allowing for memory dump of two grids:
            #      1. Build and trim and interpolate Xns
            #      2. Do rest of processing
            lstXnsAndElev = [] # limited to within catchment boundaries
##                lstTrimmedXnsAndElev = funcs.trim_and_interpolate_xns(lstReachXns, w_array, DEM_array, thisLINKNO, DEM_minVal, DEM_maxVal)
            # OR no trimming...
            lstXnsAndElev = funcs.interpolate_xns(lstReachXns, DEM_array, thisLINKNO, DEM_minVal, DEM_maxVal)

            if lstXnsAndElev:

                # Get actual distance between channel Xn points...
                XnPtDist = funcs.xn_distance_between_points(lstXnsAndElev, DEM_CellSizeX)

                # Get actual distance between valley Xn points...
                XnPtDist_Valley = funcs.xn_distance_between_points(lstValleyXns, DEM_CellSizeX)

##                if thisLINKNO == 501:
##                    arcpy.AddMessage("XnPtDist_Valley: " + str(XnPtDist_Valley))

                # Call the Analyze Xn's function (returns list of tuples: Xn num, Left Position, Right Position, Height, ...)...
                lstBankMetrics = []
                lstBankMetrics = funcs.analyze_xnelev(lstXnsAndElev, parm_ivert, thisLINKNO, XnPtDist, parm_ratiothresh, parm_slpthresh) # keep this around for plotting
                ## Returns list of: tpl_metrics = tpl_bankfullpts + (lst_total_cnt,) + (this_linkno,) + (tpl_bankfullpts[3] + np.min(tpl_thisxn[2]),) + tpl_bankangles + (bf_area,) + (ch_width,) + (overbank_ratio,)  + (total_arearatio,)

                # There's a chance no bank points and metrics will be found...
                if len(lstBankMetrics) == 0:
                    # Skip this reach altogether?
                    continue

                # Summarize metric values by reach here...
                #reach_summary = funcs.summarize_to_reach(lstBankMetrics)
                lst_TotalMetricSummary.append(funcs.summarize_to_reach(lstBankMetrics))

                # Create master Xn row/col and metrics lists for all reaches...
                lstFormattedXns = []
                lstFormattedXns = funcs.format_master_xn_list(lstXnsAndElev,thisLINKNO)

                # Format valley Xn list...
                lstFormattedValleyXns = []
                lstFormattedValleyXns = funcs.format_master_xn_list(lstValleyXns,thisLINKNO)

                # Convert bank points to map coords here...
                lstBankMetricsMap = funcs.convert_bfpositions(lstBankMetrics, lstFormattedXns, DEM_CellSizeX, DEM_ExtentLeft, DEM_ExtentBottom, DEM_RowCount, XnPtDist)

                # Add to master lists...
                lstTotalBankMetrics.extend(lstBankMetricsMap)
                lstTotalXns.extend(lstFormattedXns)
                lstTotalValleyXns.extend(lstFormattedValleyXns)

                # Update the progressor position
                arcpy.SetProgressorPosition()

##                    ## For test plotting...
##                    if DoPlots == 1 and [thisLINKNO == thisLN for thisLN in LINKNOs_to_Run]: # this is a list now??
##                        # Calculate distance in meters between points along each Xn...
##                        # NOTE: Use a distance as a slope break instead of number of pixels??
##                        XnPtDist = funcs.xn_distance_between_points(lstXnsAndElev, DEM_CellSizeX)
##                        # Plot Xn's of choice for a reach...
##                        # (I'm probably not going to run all the reaches, then pick a specific Xn along a specific reach to plot right?)
##                        funcs.plot_xn_profile_full(XnNumToPlot, lstBankMetrics, lstXnsAndElev, param_iVert, XnPtDist)

        ## END REACH LOOP
        arcpy.ResetProgressor()

        #
        if lstTotalXns:
            # Convert all row/col indices to map coordinates...
            print('Converting to map coordinates...')
            # NOTE: This function seems slow
            lstAllXnsMapCoords = [] # DON'T NEED THIS?
            lstAllXnsMapCoords = funcs.convert_xncoords(lstTotalXns, DEM_CellSizeX, DEM_ExtentLeft, DEM_ExtentBottom, DEM_RowCount)

            # Write bankpts file with elevation for use in HAR analysis...
            funcs.write_bankpts_shp(lstTotalBankMetrics, parm_bf_path, DEMspatRef)

            #Tuple to receive (tpl_reachloop_output): lstTotalBankMetrics, lst_TotalMetricSummary, lstAllXnsMapCoords, lstTotalValleyXns
            tpl_output = (lstTotalBankMetrics, lst_TotalMetricSummary, lstAllXnsMapCoords, lstTotalValleyXns, lstLINKNOs, XnPtDist_Valley)

    except arcpy.ExecuteError:
        arcpy.AddMessage(arcpy.GetMessages(2))
        print((arcpy.GetMessages(2)))

    return tpl_output
