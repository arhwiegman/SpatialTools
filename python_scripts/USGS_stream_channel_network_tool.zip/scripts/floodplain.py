#-------------------------------------------------------------------------------
# editor: by Adrian Wiemgan 2020-09-22 
# revisions:
# 	- converted from python 2.4.x to 3.x using python-modernize -w scriptname.py
#   - replaced all tabs with 4 spaces
# notes: 
# 	- these changes allow the tool to be compatible with ArcGIS Pro 2.x and python 3.x
#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      sjlamont
#
# Created:     23/03/2015
# Copyright:   (c) sjlamont 2015
# Licence:     <your licence>
#-------------------------------------------------------------------------------
from __future__ import absolute_import
from __future__ import print_function
import arcpy
from arcpy import env
from arcpy.sa import * # Spatial Analyst
from six.moves import zip
# Check out any necessary licenses
arcpy.CheckOutExtension("Spatial")
arcpy.overwriteOutputs = True

from scipy import ndimage, arange, interpolate
import numpy as np
import os.path
##-----------------------------------------------------------------------------
    # Floodplain extent via Height Above River...
##-----------------------------------------------------------------------------
def calculate_fp_extent(parm_bankpt_path, parm_dem_path, parm_net_path, parmRadius, parmHeight, parm_gridpath):
    """
        Calculates a floodplain extent grid using detrending and Height Above River (HAR)
        Analysis adapted from the Riparian Topography Toolbox
        (Dilts, T.E. and Yang, J. 2010. Riparian Topography Toolbox for ArcGIS 9.X (substitute your
        version for X). University of Nevada Reno. Available at:
        http://www.cabnr.unr.edu/weisberg/downloads

        Inputs:     1. Bank Elevation Points (with ELEV field)
                    2. Cross sections
                    3. Elevation grid/DEM
                    4. Streamlines (net.shp) --> for cost back link connectivity to stream
                    5. Search radius parameter (m)
                    6. Height threshold parameter (m)

        Outputs:    1. Floodplain extent grid (.tif)
                    2. Reach summary list?

    """
    arcpy.AddMessage("Calculating floodplain extent grid...")
    print('Calculating floodplain extent via HAR...')

    lst_fpwidth_rch = []
    parmElevFld = 'ELEV'

##    parm_testpath = r'C:\dr_Test\dr3mw.tif'
##    test_rast = arcpy.sa.Raster(parm_testpath)
##    test_extent = test_rast.extent
##    parm_dem_path = r'C:\dr_Test\dem_final.tif'

    # Get the DEM cell size...
    elevRaster = arcpy.sa.Raster(parm_dem_path)
    cellSize = float(elevRaster.meanCellWidth)
##    dem_extent = elevRaster.extent

##    props = arcpy.GetRasterProperties_management(parm_dem_path,"CELLSIZEX")
##    cellSize = float(props.getOutput(0))

    testdir = os.path.dirname(parm_bankpt_path) ## directory of file

    env.workspace = os.path.dirname(parm_bankpt_path)

    #parm_bankpt_path = r'C:\dr_Test\all_bankpts.shp'

    try:
        ##------------------------------------------------------------->
        ## Perform HAR and calculate FP grid based on input height...
        ##------------------------------------------------------------->
        print('Running HAR...')
        arcpy.AddMessage("  (1/9) Kernel Density with elevation")
        #KD_elev = KernelDensity(filename_pts, parmElevFld, cellSize, parmRadius, "SQUARE_KILOMETERS") # NOTE: FIELD NAME
        KD_elev = KernelDensity(parm_bankpt_path, parmElevFld, cellSize, parmRadius, "SQUARE_KILOMETERS") # NOTE: FIELD NAME
        KD_elev.save(r"in_memory\KD_elev")

        # # (Step 2) Process: Kernel Density reference...
        arcpy.AddMessage("  (2/9) Kernel Density reference")
        KD_ref = KernelDensity(parm_bankpt_path, "NONE", cellSize, parmRadius, "SQUARE_KILOMETERS")
        KD_ref.save(r"in_memory\KD_ref")

        # # (Step 3) Use CON statement here in case KD_Ref.tif has zero values!
        arcpy.AddMessage("  (3/9) CON statement")
        KD_ref_con = Con(Raster(r"in_memory\KD_ref"),Raster(r"in_memory\KD_ref"),0.01,"VALUE > 0")
        KD_ref_con.save(r"in_memory\KD_Ref_con")
        arcpy.Delete_management(r"in_memory\KD_ref")


        # (Step 4) Process: Divide
        arcpy.AddMessage("  (4/9) Divide to create weighted water surface elevation")
        WeightedStreamElev = Divide(r"in_memory\KD_elev", r"in_memory\KD_ref_con")
        WeightedStreamElev.save(r"in_memory\WeightedStreamElev")

        arcpy.Delete_management(r"in_memory\KD_ref_con")
        arcpy.Delete_management(r"in_memory\KD_elev")

        # (Step 5) Process: Minus
        arcpy.env.extent = parm_dem_path
        arcpy.AddMessage("  (5/9) Subtract to create base height above river grid")
        HARbase = Minus(parm_dem_path, r"in_memory\WeightedStreamElev")
        HARbase.save(r"in_memory\HARbase")

        # (Step 6) Select only a portion of HAR grid (less than some parameter to give floodplain)
        arcpy.AddMessage("  (6/9) Delineating Height Above River")
        arcpy.env.extent = parm_dem_path
        #HARbase = r"in_memory\HARbase.tif"
        FPout = Raster(r"in_memory\HARbase") < parmHeight
        FPout.save(r"in_memory\FPout")
        arcpy.Delete_management(r"in_memory\HARbase")


        # (Step ) Re-classify FP grid for Cost Back Link analysis using CON...
        arcpy.AddMessage("  (7/9) Reclassifying output with CON")
        outCon = Con(FPout==1,1)
        outConInt = Int(outCon)
        outConInt.save(r"in_memory\FP_int")
        arcpy.Delete_management(outCon)


        # (Step ) Now run Cost Back Link tool...
        arcpy.AddMessage("  (8/9) Performing Cost Back Link...")
        outBackLink = CostBackLink(parm_net_path, outConInt)
        outBackLink.save(r"in_memory\FP_backlink")
        arcpy.Delete_management(r"in_memory\FP_int")


        # (Step ) Reclassify again and save...
        arcpy.AddMessage("  (9/9) Saving final floodplain grid...")
        outCon2 = Con(outBackLink>0,1)
        outCon2.save(parm_gridpath)  # save to: parm_gridpath
        arcpy.Delete_management(r"in_memory\FP_backlink")

        arcpy.Delete_management("in_memory") # ??

    except arcpy.ExecuteError:
        arcpy.AddMessage(arcpy.GetMessages(2))
        print((arcpy.GetMessages(2)))

    return
##-----------------------------------------------------------------------------
    # Floodplain width at each input Xn using row/col pairs and FP grid...
##-----------------------------------------------------------------------------
def calculate_fp_metrics(lst_fpxn_rowcols, fp_grid_path, dem_grid_path, nodata_val, xnpt_dist, dem_min, dem_max, lst_bf_metrics):
    """
        Input Xn list is a list of tuples:

            tplValley = (lstValleyXns, thisLINKNO)

    """
    print('Calculating floodplain metrics along valley Xns...')
    arcpy.AddMessage('Calculating floodplain metrics along valley Xns...')

    lst_fp_metrics = []

    # Get FP grid as numpy array...
    FParr = arcpy.RasterToNumPyArray(fp_grid_path) #, nodata_to_value=nodata_val)
    DEMarr = arcpy.RasterToNumPyArray(dem_grid_path)

##    for tplThisRowCol in lstThisReachXns: # each  XY list
##
####        tplTrimmed = ([],[])
####        tplTrimmed = (lstTrimmedRow, lstTrimmedCol)
##        zi = ndimage.map_coordinates(DEMarray, tplThisRowCol, order=1, mode='nearest') # what order to use?
##
##        if len(zi) > parm_minlength and min(zi) >= dem_min and max(zi) <= dem_max: # make sure they are of some minimum length
##            tplXnLists = tplThisRowCol + (zi,)
##            lstTrimmedXns.append(tplXnLists)
##            #xn_cntr = xn_cntr + 1

    try:

        for this_tpl in lst_fpxn_rowcols:

            thisLINKNO = this_tpl[0]
            lstRow = this_tpl[1]
            lstCol = this_tpl[2]
            this_xnnum = this_tpl[3]

            tplThisRowCol = ([],[])
            tplThisRowCol = (lstRow,lstCol)

            # Subtract out channel width from floodplain width...
            # lst_bf_metrics:
            #                      0          1          2          3         4          5          6            7               8            9           10          11            12               13
            # lst_bfrc.append((lf_MapRow, lf_MapCol, rt_MapRow, rt_MapCol, xn_num, this_linkno, this_elev, this_bankheight, this_chwidth, this_lfang, this_rtang, this_bfarea, this_overbank, this_totarearat))
            # Get channel width from lst_bf_metrics where LINKNO's and Xn num's match...
##            lst_linkno = [tpl_i for tpl_i in lst_bf_metrics if tpl_i[5] == thisLINKNO]
##            lst_xnnum = [tpl_i for tpl_i in lst_linkno if tpl_i[4] == this_xnnum]

##            # FASTER WAY TO DO THIS?? sort??
##            # OR...
##            lst_xnnum = [tpl_i for tpl_i in lst_bf_metrics if tpl_i[5] == thisLINKNO and tpl_i[4] == this_xnnum]
##            if lst_xnnum:
##                ch_wid = lst_xnnum[0][8]
##            else:
##                ch_wid = 0

            # They're already in the same order...
            for bf_tpl in lst_bf_metrics:
                if bf_tpl[5] == thisLINKNO and bf_tpl[4] == this_xnnum:
                    ch_wid = bf_tpl[8]
                    break
                else:
                    ch_wid = 0 # not all FP Xn's have bank points

##            arcpy.AddMessage(thisLINKNO)
##            arcpy.AddMessage(this_xnnum)
##            arcpy.AddMessage(ch_wid)

##            for bf_tpl in lst_bf_metrics:
##                if bf_tpl[5] == thisLINKNO and bf_tpl[4] == this_xnnum:
##                    ch_wid = bf_tpl[8]
##                else:
##                    ch_wid = 0 # not all FP Xn's have bank points
##
##            arcpy.AddMessage(thisLINKNO)
##            arcpy.AddMessage(this_xnnum)
##            arcpy.AddMessage(ch_wid)

            # Interpolate row/cols along FP grid...
            zi_fp = ndimage.map_coordinates(FParr, tplThisRowCol, order=0, mode='nearest') # what order to use?

            # ...and for DEM...
            zi_dem = ndimage.map_coordinates(DEMarr, tplThisRowCol, order=0, mode='nearest')

            # OR, just read directly from the grid (it will interpolate linearly automatically?)...
##            zi_fp = FParr[lstRow, lstCol]
##            zi_dem = DEMarr[lstRow, lstCol]

            # 501
##            if this_xnnum == 3:
##                arcpy.AddMessage(zi_dem)

            #if min(zi_dem) >= dem_min and max(zi_dem) <= dem_max: # make sure it's within bounds of the DEM

            # Loop over output and count number of nonzeros (total number * xnptdist = FP width?)
            lst_thisxn_fpelev = []
            for cntr, this_val in enumerate(zi_fp):
                if this_val == 1:
                    lst_thisxn_fpelev.append(zi_dem[cntr]) # make a list of elevation values along Xn within the FP (includes channel)

            # Get total FP width...
            #TESTING...
##            fpelev_len = len(lst_thisxn_fpelev)
##            if thisLINKNO == 501:
##                arcpy.AddMessage(xnpt_dist)

            this_fpwidth = len(lst_thisxn_fpelev)*xnpt_dist # NOTE: need to subtract out channel width --> WHY CAN'T I MODIFY THIS LINE??

##            if thisLINKNO == 501:
##                arcpy.AddMessage("this_fpwidth" + str(this_fpwidth))

            this_fpwidth_net = this_fpwidth - ch_wid

            if this_fpwidth > 0:
                # Calculate elevation metrics...
                this_fp_min = min(lst_thisxn_fpelev)
                this_fp_max = max(lst_thisxn_fpelev)
                this_fp_range = this_fp_max - this_fp_min
                this_fp_mean = np.mean(lst_thisxn_fpelev)
                this_fp_std = np.std(lst_thisxn_fpelev)
                this_fp_sum = np.sum(lst_thisxn_fpelev)
                #this_fp_sum = sum(lst_thisxn_fpelev)
            else:
                this_fp_min = -9999
                this_fp_max = -9999
                this_fp_range = -9999
                this_fp_mean = -9999
                this_fp_std = -9999
                this_fp_sum = -9999

##            if thisLINKNO == 501 and this_xnnum == 25: # OK!
##                arcpy.AddMessage("this_fpwidth: " + str(this_fpwidth))
##                arcpy.AddMessage("this_fp_min: " + str(this_fp_min))
##                arcpy.AddMessage("this_fp_max: " + str(this_fp_max))
##                arcpy.AddMessage("this_fp_range: " + str(this_fp_range))

            tpl_output = (thisLINKNO, lstRow, lstCol, this_xnnum, this_fpwidth, this_fpwidth_net, this_fp_min, this_fp_max, this_fp_range, this_fp_mean, this_fp_std, this_fp_sum)
            lst_fp_metrics.append(tpl_output)

    except arcpy.ExecuteError:
        arcpy.AddMessage(arcpy.GetMessages(2))
        print((arcpy.GetMessages(2)))

    return lst_fp_metrics
##-----------------------------------------------------------------------------
    #               Summarize FP width to reach via median (or whatever)
##-----------------------------------------------------------------------------
def summarize_fpmetrics_by_reach(lst_fpmetrics, lst_uniqueids):
    """
        Input:
            A list of:
                                 0         1       2        3             4              5              6              7            8              9           10           11
              tpl_output = (thisLINKNO, lstRow, lstCol, this_xnnum, this_fpwidth, this_fpwidth_net, this_fp_min, this_fp_max, this_fp_range, this_fp_mean, this_fp_std, this_fp_sum)

    """

    lst_medianvals = []

    try:

        for this_linkno in lst_uniqueids:

            lst_out = [list(tpl_fp) for tpl_fp in lst_fpmetrics if tpl_fp[0] == this_linkno]

            if (len(lst_out) > 0):

##                arcpy.AddMessage('Length of lst_out:')
##                arcpy.AddMessage(len(lst_out))

                lst_zip = []
                lst_zip = list(zip(*lst_out)) # unzip/transpose the list of tuples


                # Ignore NoData vals...
##                for this_lst in lst_zip:
##                    if this_lst[4] >= 0:
##                        lst
                #if len(lst_zip) > 0:
                # something like lst_zip[4] > 0
                fpwidtot = np.median([i for i in lst_zip[4] if i >= 0])
                fpwidnet = np.median([i for i in lst_zip[5] if i >= 0])
                fpmin = np.median([i for i in lst_zip[6] if i >= 0])
                fpmax = np.median([i for i in lst_zip[7] if i >= 0])
                fprange = np.median([i for i in lst_zip[8] if i >= 0])
                fpmean = np.median([i for i in lst_zip[9] if i >= 0])
                fpstd = np.median([i for i in lst_zip[10] if i >= 0])
                fpsum = np.median([i for i in lst_zip[11] if i >= 0])

##                if this_linkno == 501:
##                    arcpy.AddMessage("fpwidtot: " + str(fpwidtot))

##                fpwid = np.median(lst_zip[4])
##                fpmin = np.median(lst_zip[5])
##                fpmax = np.median(lst_zip[6])
##                fprange = np.median(lst_zip[7])
##                fpmean = np.median(lst_zip[8])
##                fpstd = np.median(lst_zip[9])
##                fpsum = np.median(lst_zip[10])

                tpl_out = (this_linkno, fpwidtot,fpwidnet,fpmin,fpmax,fprange,fpmean,fpstd,fpsum)
                lst_medianvals.append(tpl_out)


##        lst_fpmetrics_sorted = sorted(lst_fpmetrics,  key=lambda x: x[0])
##        lst_uniqueids_sorted = sorted(lst_uniqueids)
##
##        for this_linkno in lst_uniqueids_sorted:
##
##            lst_wid = []
##            lst_min = []
##            lst_max = []
##            lst_range = []
##            lst_mean = []
##            lst_std = []
##            lst_sum = []
##
##            bool_flag = False
##            for this_tpl in lst_fpmetrics_sorted:
##                if this_tpl[0] == this_linkno:
##                    lst_wid.append(this_tpl[4])
##                    lst_min.append(this_tpl[5])
##                    lst_max.append(this_tpl[6])
##                    lst_range.append(this_tpl[7])
##                    lst_mean.append(this_tpl[8])
##                    lst_std.append(this_tpl[9])
##                    lst_sum.append(this_tpl[10])
##                    bool_flag = True
##
##            if bool_flag:
##                fpwid = np.median(lst_wid)
##                fpmin = np.median(lst_min)
##                fpmax = np.median(lst_max)
##                fprange = np.median(lst_range)
##                fpmean = np.median(lst_mean)
##                fpstd = np.median(lst_std)
##                fpsum = np.median(lst_sum)
##
##                tpl_out = (this_linkno, fpwid,fpmin,fpmax,fprange,fpmean,fpstd,fpsum)
##                lst_medianvals.append(tpl_out)

    except arcpy.ExecuteError:
        arcpy.AddMessage(arcpy.GetMessages(2))
        print(arcpy.GetMessages(2))

    return lst_medianvals


