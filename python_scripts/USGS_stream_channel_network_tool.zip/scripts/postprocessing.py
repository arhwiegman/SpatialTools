#-------------------------------------------------------------------------------
# editor: by Adrian Wiemgan 2020-09-22 
# revisions:
# 	- converted from python 2.4.x to 3.x using python-modernize -w scriptname.py
#   - replaced all tabs with 4 spaces
# notes: 
# 	- these changes allow the tool to be compatible with ArcGIS Pro 2.x and python 3.x
#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      sjlamont
#
# Created:     07/02/2015
# Copyright:   (c) sjlamont 2015
# Licence:     <your licence>
#-------------------------------------------------------------------------------
from __future__ import absolute_import
from __future__ import print_function
import arcpy
from arcpy import env
from arcpy.sa import * # Spatial Analyst
arcpy.CheckOutExtension("Spatial")
env.overwriteOutput = True
env.qualifiedFieldNames = False

import os

def Processor(params):

    try:

        # PART 1 ------------------------------------------------------------------>
        # Summary: Defines projection for net.shp, converts w.tif to a .shp, dissolves
        #          that .shp on GRIDCODE, and joins net.shp attributes to it

        # Input...
##        strWpath = ''  # (NOTE: Do these have to be initialized?? I don't get it)
##        strNETpath = ''
##        path_w = ''
        # params = [paramDEM, paramFDR, paramWgrid, paramNETshp]

        if params[0].value:
            desc = arcpy.Describe(params[0].value)
            path_dem = desc.path
            filename_dem = desc.file
            strDEMpath = str(path_dem) + "/" + filename_dem

        if params[1].value:
            desc = arcpy.Describe(params[1].value)
            path_fdr = desc.path
            filename_fdr = desc.file
            strFDRpath = str(path_fdr) + "/" + filename_fdr

        if params[2].value:
            desc = arcpy.Describe(params[2].value)
            path_w = desc.path
            filename_w = desc.file
            strWpath = str(path_w) + "/" + filename_w

        if params[3].value:
            desc = arcpy.Describe(params[3].value)
            path_net = desc.path
            filename_net = desc.file
            strNETpath = str(path_net) + "/" + filename_net



        # Output...
        # Set these automatically, unbeknownst to user (heh)
        # Get all characters before 'fel.tif'...
        str_outprefix = os.path.splitext(filename_dem)[0]
        #str_outprefix = filename_dem.rsplit('fel',1)[0]
        str_dem_out = str_outprefix + '_dem_post.tif'
        str_fdr_out = str_outprefix + '_fdr_post.tif'
        str_w_out = str_outprefix + '_w_post.tif'
        str_stpts_out = str_outprefix + '_stpts_post.tif'

        #arcpy.AddMessage(str_dem_out)

        # NOTE: just set the workspace environment to that of one of the input grids
        env.workspace = str(path_w)

        # (1) Get cell size and spatial reference from the catchment grid...
        arcpy.AddMessage("(1/12) Getting cell size and spatial reference...")
        Wprops = arcpy.GetRasterProperties_management(strWpath,"CELLSIZEX")
        cellSize = float(Wprops.getOutput(0))
        Wdesc = arcpy.Describe(strWpath)
        SpatRef = Wdesc.spatialReference

        # (2) Define projection for net.shp...
        arcpy.AddMessage("(2/12) Defining spatial reference for net.shp")
        arcpy.DefineProjection_management(strNETpath, SpatRef)

        # (3) Convert w.tif to w.shp...
        arcpy.AddMessage("(3/12) Converting w.tif to w.shp...")
        w_shp = "temp_w.shp"
        field = "VALUE"
        arcpy.RasterToPolygon_conversion(strWpath, w_shp, "NO_SIMPLIFY", field)

        # (4) Dissolve w.shp on GRIDCODE...
        arcpy.AddMessage("(4/12) Dissolving w.shp on GRIDCODE")
        w_diss = "temp_wdiss.shp"
##        arcpy.AddMessage(Dissolving w.shp on GRIDCODE...)
        arcpy.Dissolve_management(w_shp, w_diss, "GRIDCODE")

        # (5) Join net.shp to wdiss.shp and export...
        arcpy.AddMessage("(5/12) Joining net.shp attributes to catchment layer")
        w_diss_fl = "tempwFlyr"
        arcpy.MakeFeatureLayer_management(w_diss, w_diss_fl)
        arcpy.AddJoin_management(w_diss_fl, "GRIDCODE", strNETpath, "LINKNO", "KEEP_ALL")
        w_join = "temp_wjoin.shp"
        arcpy.CopyFeatures_management(w_diss_fl, w_join)

    # PART 2 ------------------------------------------------------------------>

        # ( ) Clip net.shp to shed catchments...
        #print "Clipping net.shp..."
        arcpy.AddMessage("(6/12) Clipping net.shp to catchment layer...")
        arcpy.Clip_analysis(strNETpath, "temp_w.shp", "net_shed.shp")

        # NOTE: Assumes extent of the catchment grid is the same as the DEM and FDR?
        # (6) Convert catchSHED back to catchTIF on LINKNO...
        arcpy.env.extent = strWpath # will this be set for ALL following operations??
        arcpy.AddMessage("(7/12) Saving final catchment file as .tif...")
        arcpy.FeatureToRaster_conversion(w_join, "LINKNO", str_w_out, cellSize)

        # ( ) Convert net.shp to .tif on LINKNO...
        arcpy.env.extent = strWpath # will this be set for ALL following operations??
        print("Converting net.shp to .tif...")
        arcpy.FeatureToRaster_conversion("net_shed.shp", "LINKNO", "net_shed.tif", cellSize)

        # (7) Channel Heads...
        arcpy.env.extent = strWpath
        arcpy.AddMessage("(8/12) Creating channel head points file...")
        netSHPshed_endPts = "temp_netPts.shp"
        arcpy.FeatureVerticesToPoints_management("net_shed.shp", "net_shed_pts.shp", "END")

        # (8) Convert these to .tif...
        arcpy.AddMessage("(9/12) Saving final channel initiation points file as .tif")
        arcpy.env.extent = strWpath # will this be set for ALL following operations??
        arcpy.FeatureToRaster_conversion("net_shed_pts.shp", "LINKNO", str_stpts_out, cellSize)

        # ( ) Extract DEM using catchSHED using the processing extent of catchSHED...
        arcpy.env.extent = strWpath # will this be set for ALL following operations??
        arcpy.AddMessage("(10/12) Clipping DEM")
        #print "Clipping DEM..."
        outDEM = ExtractByMask(strDEMpath, str_w_out)
        outDEM.save(str_dem_out)

        # ( ) Extract FDR using catchSHED using the processing extent of catchSHED...
        arcpy.AddMessage("(11/12) Clipping FDR")
        arcpy.env.extent = strWpath # will this be set for ALL following operations??
        #print "Clipping FDR..."
        outDEM = ExtractByMask(strFDRpath, str_w_out)
        outDEM.save(str_fdr_out)

        # Delete unneccesary files...
        arcpy.AddMessage("(12/12) Cleaning up")
        arcpy.Delete_management("net_shed.shp")
        arcpy.Delete_management("net_shed.tif")
        arcpy.Delete_management("net_shed_pts.shp")
        arcpy.Delete_management("temp_w.shp")
        arcpy.Delete_management("net_shed.shp")
        arcpy.Delete_management("temp_wjoin.shp")
        arcpy.Delete_management("temp_w.shp")
        arcpy.Delete_management("temp_wdiss.shp")
        #arcpy.Delete_management()

        # Add final output layers to map
        # Get current map and data frame...
        mxd = arcpy.mapping.MapDocument("CURRENT")
        df = arcpy.mapping.ListDataFrames(mxd, "*")[0]
        # Get output layers...
        w_sourceLayer = arcpy.mapping.Layer(str_w_out)
        stpts_sourceLayer = arcpy.mapping.Layer(str_stpts_out)
        fdr_sourceLayer = arcpy.mapping.Layer(str_fdr_out)
        dem_sourceLayer = arcpy.mapping.Layer(str_dem_out)
        # Add layers...
        arcpy.mapping.AddLayer(df,w_sourceLayer,"TOP")
        arcpy.mapping.AddLayer(df,stpts_sourceLayer,"TOP")
        arcpy.mapping.AddLayer(df,fdr_sourceLayer,"TOP")
        arcpy.mapping.AddLayer(df,dem_sourceLayer,"TOP")
        # Refresh view...
        arcpy.RefreshActiveView()


    except arcpy.ExecuteError:
        arcpy.AddMessage(arcpy.GetMessages(2))

    ## NOTE: extents should be equal out of TauDEM by default (no need since I'm not doing any intermediate steps)
##    try:
##      # (5) Extract DEM using catchSHED using the processing extent of catchSHED...
##      arcpy.env.extent = catchSHED # will this be set for ALL following operations??
##      print "Clipping DEM..."
##      outDEM = ExtractByMask(inDEM, strDEMout_final)
##      outDEM.save(strDEMout_path)
##
##    except arcpy.ExecuteError:
##      print(arcpy.GetMessages(2))
##
##    try:
##      # (6) Extract FDR using catchSHED using the processing extent of catchSHED...
##      arcpy.env.extent = catchSHED # will this be set for ALL following operations??
##      print "Clipping FDR..."
##      outDEM = ExtractByMask(inFDR, strFDRout_final)
##      outDEM.save(strFDRout_path)
##
##    except arcpy.ExecuteError:
##      print(arcpy.GetMessages(2))

    return
